(function () {
  'use strict';

  var connections = [];
  var clients = [
    { id: 'client-001', name: 'Aquasure', external_id: 'aquasure', custom_object_fields: {} },
    { id: 'client-002', name: 'BetterMeRX', external_id: 'bettermrx', custom_object_fields: {} },
    { id: 'client-003', name: 'Inspire Uplift', external_id: 'inspire-uplift', custom_object_fields: {} }
  ];
  var fields = [
    { key: 'cxe_client', type: 'lookup', relationship_target_type: 'zen:custom_object:client' },
    { key: 'cxe_domain', type: 'text' },
    { key: 'cxe_api_email', type: 'text' },
    { key: 'cxe_auth_type', type: 'dropdown' },
    { key: 'cxe_access_token', type: 'textarea' },
    { key: 'cxe_enabled', type: 'checkbox' },
    { key: 'cxe_connection_status', type: 'dropdown' },
    { key: 'cxe_last_test_at', type: 'text' },
    { key: 'cxe_last_sync_at', type: 'text' },
    { key: 'cxe_last_http_status', type: 'integer' },
    { key: 'cxe_last_error', type: 'textarea' },
    { key: 'cxe_credential_updated_at', type: 'text' },
    { key: 'cxe_auth_version', type: 'text' }
  ];

  function jsonBody(options) {
    return options.data ? JSON.parse(options.data) : {};
  }

  function externalId(url) {
    return new URL(url, 'https://pdi-cx-experts.zendesk.com').searchParams.get('external_id');
  }

  function request(input) {
    var options = typeof input === 'string' ? { url: input, type: 'GET' } : input;
    var url = options.url;
    var method = (options.type || 'GET').toUpperCase();
    if (/\/custom_objects\/client\/records/.test(url)) return Promise.resolve({ custom_object_records: clients, meta: { has_more: false } });
    if (/\/custom_objects\/cxe_zd_sync_connection\/records/.test(url) && method === 'GET') return Promise.resolve({ custom_object_records: connections, meta: { has_more: false } });
    if (/\/custom_objects\/cxe_zd_sync_connection\/records/.test(url) && method === 'PATCH') {
      var recordBody = jsonBody(options).custom_object_record;
      var id = externalId(url);
      var existing = connections.findIndex(function (record) { return record.external_id === id; });
      var record = { id: existing >= 0 ? connections[existing].id : 'connection-' + (connections.length + 1), external_id: id, name: recordBody.name, custom_object_fields: recordBody.custom_object_fields };
      if (existing >= 0) connections[existing] = record; else connections.push(record);
      return Promise.resolve({ custom_object_record: record });
    }
    if (/\/custom_objects\/cxe_zd_sync_connection\/records/.test(url) && method === 'DELETE') {
      var deleteId = externalId(url);
      connections = connections.filter(function (record) { return record.external_id !== deleteId; });
      return Promise.resolve({});
    }
    if (/\/custom_objects\/cxe_zd_sync_connection\/fields/.test(url)) return Promise.resolve({ custom_object_fields: fields });
    if (/\/custom_objects\/(client|cxe_zd_sync_connection)$/.test(url)) return Promise.resolve({ custom_object: { key: url.split('/').pop() } });
    if (url === '/api/v2/custom_objects' && method === 'POST') return Promise.resolve({ custom_object: { key: 'cxe_zd_sync_connection' } });
    return Promise.resolve({});
  }

  window.ZAFClient = {
    init: function () {
      return {
        get: function () { return Promise.resolve({ currentUser: { id: 'admin-001', name: 'Amina Dlamini', role: 'admin' } }); },
        invoke: function () { return Promise.resolve(); },
        request: request
      };
    }
  };

  window.fetch = async function (input, options) {
    var url = new URL(input);
    if (!options || options.headers.Authorization !== 'Bearer test-oauth-token') return response({ error: 'Unauthorized' }, 401);
    var path = url.pathname;
    if (path === '/api/v2/users/me.json') return response({ user: { id: 1001, name: 'Test OAuth Admin' } });
    if (path === '/api/v2/help_center/locales.json') return response({ locales: ['en-us'], default_locale: 'en-us' });
    if (/\/help_center\/en-us\/categories\.json$/.test(path)) return response({ categories: [{ id: 301, name: 'Getting started' }], next_page: null });
    if (/\/help_center\/en-us\/sections\.json$/.test(path)) return response({ sections: [{ id: 302, name: 'Account setup' }], next_page: null });
    if (/\/help_center\/en-us\/articles\.json$/.test(path)) return response({ articles: [{ id: 303, title: 'Configure your account', draft: false }], next_page: null });
    if (/\/custom_objects\/device\/fields$/.test(path)) return response({ custom_object_fields: [{ id: 401, key: 'serial_number', title: 'Serial number', type: 'text' }], links: { next: null } });
    if (path === '/api/v2/custom_objects') return response({ custom_objects: [{ id: 400, key: 'device', title: 'Device' }], links: { next: null } });
    var roots = {
      '/api/v2/groups.json': 'groups', '/api/v2/views.json': 'views', '/api/v2/users.json': 'users',
      '/api/v2/recipient_addresses.json': 'recipient_addresses', '/api/v2/business_hours/schedules.json': 'schedules',
      '/api/v2/ticket_forms.json': 'ticket_forms', '/api/v2/ticket_fields.json': 'ticket_fields', '/api/v2/tags.json': 'tags',
      '/api/v2/custom_statuses.json': 'custom_statuses', '/api/v2/slas/policies.json': 'sla_policies',
      '/api/v2/automations.json': 'automations', '/api/v2/triggers.json': 'triggers', '/api/v2/trigger_categories': 'trigger_categories',
      '/api/v2/macros.json': 'macros', '/api/v2/brands.json': 'brands', '/api/v2/user_fields.json': 'user_fields',
      '/api/v2/organization_fields.json': 'organization_fields'
    };
    var root = roots[path];
    if (root) {
      var data = { next_page: null };
      data[root] = [{ id: root + '-001', name: 'Example ' + root.replace(/_/g, ' '), active: true, conditions: { all: [{ field: 'status', operator: 'is', value: 'open' }] } }];
      return response(data);
    }
    return response({ error: 'Not found' }, 404);
  };

  function response(data, status) {
    return new Response(JSON.stringify(data), { status: status || 200, headers: { 'Content-Type': 'application/json' } });
  }
})();
