# Security Notes

## Threat boundary

This is a private CX Experts Zendesk app, but being behind Zendesk login does not make secrets embedded in JavaScript secret. Every static file shipped in the ZIP can be inspected by an authorised browser session.

## Credential storage

At the user's direction, the POC has no vault passphrase. It stores the OAuth token directly in the app-owned `cxe_zd_sync_connection.cxe_access_token` field after testing it. This removes the repeated unlock step but does not provide app-level encryption.

Restrict the private app and connection-object access to the authorised internal CX Experts roles. Stronger secret isolation requires a server-side secret store or Zendesk Integration Services (ZIS); a static browser ZIP cannot keep a decryption key secret from its users.

## Why API token mode is not active

Zendesk does not support authenticated browser CORS with Zendesk API tokens, and ZAF cannot proxy a request to another Zendesk Support instance. Cross-instance browser sync therefore uses OAuth bearer tokens.

## Outbound protection

The runtime normalises and validates client domains and allows only HTTPS hosts ending in `.zendesk.com`. Pagination is rejected if Zendesk returns a next-page URL on another host.

## Data handling

Configuration is held in memory for the current app session. No ticket corpus or snapshot database is created. Copy-for-AI and exports recursively strip keys that look like credentials, authorization headers, secrets, passwords, tokens, or API keys.
