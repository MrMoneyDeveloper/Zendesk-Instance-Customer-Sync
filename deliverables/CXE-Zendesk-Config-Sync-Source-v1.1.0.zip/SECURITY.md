# Security Notes

## Threat boundary

This is a private CX Experts Zendesk app, but being behind Zendesk login does not make secrets embedded in JavaScript secret. Every static file shipped in the ZIP can be inspected by an authorised browser session.

## Credential storage

The POC has no vault passphrase. The Node relay tests the API token and seals it with AES-256-GCM using a server-held key. Only the connection-bound envelope is stored in `cxe_zd_sync_connection.cxe_credential_envelope`. The raw token is not persisted by the relay or stored in the Zendesk record.

Restrict the private app and connection-object access to authorised internal CX Experts roles. Keep the relay encryption key and shared relay secret in the hosting platform's secret environment storage.

## API-token transport

Zendesk does not support authenticated browser CORS with Zendesk API tokens, and ZAF cannot proxy a request directly to another Zendesk Support instance. The app therefore sends an authenticated request to the CXE relay, which performs the Zendesk request server-to-server.

## Outbound protection

The relay normalises and validates client domains and allows only HTTPS hosts ending in `.zendesk.com`. It accepts only predefined read-only configuration section keys, never arbitrary paths. Pagination is rejected if Zendesk returns a next-page URL on another host.

## Data handling

Configuration is held in memory for the current app session. No ticket corpus or snapshot database is created. Copy-for-AI and exports recursively strip keys that look like credentials, authorization headers, secrets, passwords, tokens, or API keys.
