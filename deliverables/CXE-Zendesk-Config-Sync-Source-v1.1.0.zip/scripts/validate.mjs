import { readFile, stat } from 'node:fs/promises';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('..', import.meta.url));
const app = join(root,'zendesk-app');
const required=['manifest.json','requirements.json','translations/en.json','assets/iframe.html','assets/app.js','assets/styles.css','assets/record-overrides.css','assets/icon_nav_bar.svg','assets/logo.png','assets/logo-small.png','assets/react.production.min.js','assets/react-dom.production.min.js'];
let failed=false;
for (const f of required){ try{ await stat(join(app,f)); console.log('OK ',f); }catch{ console.error('MISS',f); failed=true; } }
for (const f of ['manifest.json','requirements.json','translations/en.json']){ try{ JSON.parse(await readFile(join(app,f),'utf8')); }catch(e){ console.error('JSON',f,e.message); failed=true; } }
const manifest=JSON.parse(await readFile(join(app,'manifest.json'),'utf8'));
if(manifest.location?.support?.nav_bar!=='assets/iframe.html'){console.error('Manifest nav_bar must point to assets/iframe.html');failed=true;}
const relayUrl=manifest.parameters?.find(parameter=>parameter.name==='relay_url');
const relaySecret=manifest.parameters?.find(parameter=>parameter.name==='relay_secret');
if(!relayUrl?.required || !relaySecret?.required || relaySecret.secure!==true){console.error('Manifest must require relay_url and secure relay_secret settings');failed=true;}
const requirements=JSON.parse(await readFile(join(app,'requirements.json'),'utf8'));
const objs=requirements.custom_objects_v2?.objects||[];
if(!objs.some(o=>o.key==='cxe_zd_sync_connection')){console.error('Missing cxe_zd_sync_connection requirement');failed=true;}
const fields=requirements.custom_objects_v2?.object_fields||[];
if(fields.length>20){console.error('App requirements exceed Zendesk 20-field/object requirement limit');failed=true;}
const lookup=fields.find(f=>f.key==='cxe_client');
if(!lookup || lookup.relationship_target_type!=='zen:custom_object:client'){console.error('Client lookup relationship is missing or targets the wrong object');failed=true;}
const syntax=spawnSync(process.execPath,['--check',join(app,'assets','app.js')],{encoding:'utf8'});
if(syntax.status!==0){console.error(syntax.stderr);failed=true;}else console.log('OK  JavaScript syntax');
const appSource=await readFile(join(app,'assets','app.js'),'utf8');
if(/[ÃÂâ]/.test(appSource)){console.error('Application JavaScript contains mojibake characters');failed=true;}
const packageJson=JSON.parse(await readFile(join(root,'package.json'),'utf8'));
const reactSource=await readFile(join(app,'assets','react.production.min.js'));
const reactDomSource=await readFile(join(app,'assets','react-dom.production.min.js'));
const expectedReact=await readFile(join(root,'node_modules','react','umd','react.production.min.js'));
const expectedReactDom=await readFile(join(root,'node_modules','react-dom','umd','react-dom.production.min.js'));
if(packageJson.devDependencies?.react!=='18.3.1' || packageJson.devDependencies?.['react-dom']!=='18.3.1' || !reactSource.equals(expectedReact) || !reactDomSource.equals(expectedReactDom)){
  console.error('Expected matched React and ReactDOM 18.3.1 production runtimes');failed=true;
}
if(failed) process.exit(1);
console.log('Local structural validation passed. Run npm run zendesk:validate after npm install for official ZCLI validation.');
