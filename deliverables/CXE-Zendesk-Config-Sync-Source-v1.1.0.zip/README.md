# CX Experts Zendesk Configuration Sync

Private, read-only Zendesk Support app for `pdi-cx-experts.zendesk.com`.

## What this build is

This build has two deliberately small components:

- a client-side React/ZAF app delivered as one Zendesk upload ZIP
- a stateless Node.js relay that performs cross-instance API-token requests

The relay has no database and stores no configuration snapshots.

## Runtime architecture

1. The app uses `ZAFClient.init()` inside CX Experts Zendesk.
2. The existing custom object `client` is the authoritative client directory.
3. `requirements.json` provisions the app-owned `cxe_zd_sync_connection` object.
4. Connection records use a lookup field to `zen:custom_object:client` and deterministic external id `cxe-config:{CLIENT_RECORD_ID}`.
5. The app sends a selected connection's encrypted credential envelope to the Node relay using a ZAF request authenticated by a secure installation setting.
6. The relay decrypts the API token in memory and reads allowlisted configuration endpoints from the selected client instance.
7. Current configuration is returned to browser memory only. It is not backed up or snapshotted.
8. Users can inspect tabs, copy LLM-friendly Markdown, copy JSON, and export CSV/JSON.

## Important authentication constraint

A Zendesk-hosted ZIP cannot use an API token directly against a different Zendesk Support instance because browser CORS rejects API-token authentication. The stateless relay makes this request server-to-server, so the connection UI can accept each client's domain, API email, and API token without hardcoding them.

### Credential storage

The app has no vault passphrase. During Connect/Replace credential, the raw API token is sent to the authenticated relay for a real `/api/v2/users/me.json` test. Only after a successful test does the relay return an AES-256-GCM envelope bound to the Client id, domain, and email. The envelope is stored in `cxe_zd_sync_connection.cxe_credential_envelope`; the raw token is not saved in Zendesk.

The relay encryption key stays in the Node host environment. Changing it requires reconnecting saved credentials.

## App-owned custom object

`cxe_zd_sync_connection`

Fields:

- `cxe_client` lookup → `client`
- `cxe_domain`
- `cxe_api_email`
- `cxe_auth_type`
- `cxe_credential_envelope`
- `cxe_enabled`
- `cxe_connection_status`
- `cxe_last_test_at`
- `cxe_last_sync_at`
- `cxe_last_http_status`
- `cxe_last_error`
- `cxe_credential_updated_at`
- `cxe_auth_version`

The app never uses the existing `client.api_key__conversation_and_other_` field as its credential store.

## Schema upgrades

Stable object and field **keys** are the contract. Installation/update uses `requirements.json`; runtime **Setup / Repair** additionally verifies the schema and, for admins, creates only missing app-owned resources.

Repair is intentionally additive/idempotent. It does not delete or recreate existing connection records or fields.

## Supported config sync

The POC pulls configuration only:

- Groups
- Views
- Agents
- Inbound channels
- Operating hours
- Custom objects
- Custom-object fields
- Ticket forms
- Ticket fields
- Tags
- Custom statuses
- SLA policies
- Automations
- Triggers
- Trigger categories
- Macros
- Brands
- User fields
- Organisation fields
- Help Centre categories/sections/articles

It does **not** retrieve ticket lists, comments, requesters, ticket audits, or customer conversations.

## Development

Requires Node.js 20+.

```powershell
npm install
npm run build
npm test
npm run validate:local
```

For Zendesk's official validator/package flow:

```powershell
npm run zendesk:validate
npm run zendesk:package
```

Or install directly with the active ZCLI profile:

```powershell
npm run zendesk:create
```

## Manual upload to CX Experts

A ready-to-upload ZIP is included separately as `CXE-Zendesk-Config-Sync-POC-v1.1.0.zip`.

In `pdi-cx-experts.zendesk.com`:

1. Admin Center → Apps and integrations → Apps → Zendesk Support apps.
2. Upload App.
3. Select `CXE-Zendesk-Config-Sync-POC-v1.1.0.zip`.
4. Enable the appropriate **role/group restrictions** for the internal CX Experts users who should access it.
5. Enter the deployed HTTPS relay URL and relay shared secret when Zendesk asks for app settings.
6. Install.
7. Open **CXE Zendesk Config Sync** from the Support navigation bar.
8. Open **Setup / Repair** and verify every schema check is green.
9. Connect a test client with its Zendesk API email and API token.
10. Test connection before running a full sync.

## Relay setup

Deploy `relay/` to a Node 20+ HTTPS host. Configure `CXE_RELAY_SECRET`, `CXE_ENCRYPTION_KEY`, and `CXE_ENCRYPTION_KEY_ID` as documented in `relay/README.md`. Use the same relay secret in the Zendesk app's secure installation setting.

## Error handling

- `401`: credential invalid/expired/revoked
- `403`: permission issue
- `404`: optional feature unavailable
- `429`: controlled relay retry using `Retry-After`
- `5xx`: controlled retry/backoff
- unexpected redirect/host: blocked
- only HTTPS `*.zendesk.com` client hosts are permitted

## Files

- `zendesk-app/` — uploadable Zendesk app root
- `src/` — application source
- `vendor/` — vendored React runtime used by the self-contained ZIP
- `scripts/build.mjs` — Node build copier
- `scripts/validate.mjs` — local structural validation
- `tests/app.test.mjs` — Node automated checks

## Current sync model

The app synchronises while an authorised internal user has it open and clicks Sync. The relay is stateless and does not run scheduled background jobs.
