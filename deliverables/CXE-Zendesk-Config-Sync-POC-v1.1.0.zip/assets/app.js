(function () {
  'use strict';

  var h = React.createElement;
  var CONNECTION_OBJECT = 'cxe_zd_sync_connection';
  var CLIENT_OBJECT = 'client';
  var TOKEN_STORAGE_VERSION = 'relay-aes-gcm-v1';
  var MAX_PAGES = 100;
  var ZAF = window.ZAFClient ? window.ZAFClient.init() : null;
  var RELAY_URL = '';

  var SOURCE_DEFS = [
    { key:'groups', label:'Groups', endpoint:'/api/v2/groups.json', root:'groups' },
    { key:'views', label:'Views', endpoint:'/api/v2/views.json', root:'views' },
    { key:'agents', label:'Agents', endpoint:'/api/v2/users.json?role%5B%5D=agent&role%5B%5D=admin', root:'users' },
    { key:'recipient_addresses', label:'Inbound Channels', endpoint:'/api/v2/recipient_addresses.json', root:'recipient_addresses' },
    { key:'business_hours', label:'Operating Hours', endpoint:'/api/v2/business_hours/schedules.json', root:'schedules' },
    { key:'custom_objects', label:'Custom Objects', endpoint:'/api/v2/custom_objects', root:'custom_objects', optional:true },
    { key:'ticket_forms', label:'Forms', endpoint:'/api/v2/ticket_forms.json', root:'ticket_forms' },
    { key:'ticket_fields', label:'Fields', endpoint:'/api/v2/ticket_fields.json', root:'ticket_fields' },
    { key:'tags', label:'Tags', endpoint:'/api/v2/tags.json', root:'tags', optional:true },
    { key:'custom_statuses', label:'Statuses', endpoint:'/api/v2/custom_statuses.json', root:'custom_statuses', optional:true },
    { key:'sla_policies', label:'SLA', endpoint:'/api/v2/slas/policies.json', root:'sla_policies', optional:true },
    { key:'automations', label:'Automations', endpoint:'/api/v2/automations.json', root:'automations' },
    { key:'triggers', label:'Triggers', endpoint:'/api/v2/triggers.json', root:'triggers' },
    { key:'trigger_categories', label:'Trigger Categories', endpoint:'/api/v2/trigger_categories', root:'trigger_categories', optional:true },
    { key:'macros', label:'Macros', endpoint:'/api/v2/macros.json', root:'macros' },
    { key:'brands', label:'Brands', endpoint:'/api/v2/brands.json', root:'brands', optional:true },
    { key:'user_fields', label:'User Fields', endpoint:'/api/v2/user_fields.json', root:'user_fields', optional:true },
    { key:'organization_fields', label:'Organization Fields', endpoint:'/api/v2/organization_fields.json', root:'organization_fields', optional:true }
  ];

  var GENERATED_DEFS = [
    { key:'custom_object_fields', label:'Custom Object Fields', generated:'custom_object_fields' },
    { key:'help_centre_categories', label:'Help Centre Categories', helpCentre:'categories' },
    { key:'help_centre_sections', label:'Help Centre Sections', helpCentre:'sections' },
    { key:'help_centre_articles', label:'Help Centre Articles', helpCentre:'articles' }
  ];

  var REQUIRED_FIELDS = [
    {key:'cxe_client',title:'Client',type:'lookup',relationship_target_type:'zen:custom_object:client'},
    {key:'cxe_domain',title:'Zendesk Domain',type:'text'},
    {key:'cxe_api_email',title:'API / Integration Email',type:'text'},
    {key:'cxe_auth_type',title:'Authentication Type',type:'dropdown',custom_field_options:[{name:'API Token via CXE Relay',value:'api_token'}]},
    {key:'cxe_credential_envelope',title:'Encrypted Credential Envelope',type:'textarea'},
    {key:'cxe_enabled',title:'Enabled',type:'checkbox'},
    {key:'cxe_connection_status',title:'Connection Status',type:'dropdown',custom_field_options:[{name:'Connected',value:'connected'},{name:'Credential invalid',value:'invalid'},{name:'Disabled',value:'disabled'},{name:'Permission issue',value:'permission_issue'},{name:'Error',value:'error'}]},
    {key:'cxe_last_test_at',title:'Last Connection Test',type:'text'},
    {key:'cxe_last_sync_at',title:'Last Successful Sync',type:'text'},
    {key:'cxe_last_http_status',title:'Last HTTP Status',type:'integer'},
    {key:'cxe_last_error',title:'Last Error',type:'textarea'},
    {key:'cxe_credential_updated_at',title:'Credential Updated At',type:'text'},
    {key:'cxe_auth_version',title:'Credential Storage Version',type:'text'}
  ];

  function nowIso(){ return new Date().toISOString(); }
  function arr(x){ return Array.isArray(x) ? x : []; }
  function safeString(v){ return v == null ? '' : String(v); }
  function humanTime(v){ if(!v) return 'Never'; try{return new Date(v).toLocaleString();}catch(e){return v;} }
  function objectName(x){ return safeString(x && (x.name || x.title || x.raw_title || x.key || x.id)) || 'Untitled'; }

  function normalizeDomain(value){
    var s=safeString(value).trim().toLowerCase().replace(/^https?:\/\//,'').replace(/\/$/,'');
    s=s.split('/')[0];
    if(!/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.zendesk\.com$/.test(s)) throw new Error('Enter a valid Zendesk subdomain such as client.zendesk.com.');
    return s;
  }

  function sectionDef(key){
    return SOURCE_DEFS.concat(GENERATED_DEFS).find(function(def){return def.key===key;});
  }

  function expectedFieldType(field){
    if(!field) return '';
    return field.key==='cxe_client' ? field.type+'|'+safeString(field.relationship_target_type) : field.type;
  }

  function zafRequest(url, method, body){
    if(!ZAF) return Promise.reject(new Error('This operation requires the app to run inside Zendesk.'));
    var opts={url:url,type:method||'GET',dataType:'json'};
    if(body!==undefined){ opts.contentType='application/json'; opts.data=JSON.stringify(body); }
    return ZAF.request(opts);
  }

  async function ensureRelaySettings(){
    if(RELAY_URL) return RELAY_URL;
    if(!ZAF) throw new Error('This operation requires the app to run inside Zendesk.');
    var metadata=await ZAF.metadata(), raw=safeString(metadata && metadata.settings && metadata.settings.relay_url).trim().replace(/\/$/,'');
    if(!raw) throw new Error('The CXE relay URL is missing from the app installation settings.');
    var parsed;
    try{parsed=new URL(raw);}catch(ignore){throw new Error('The configured CXE relay URL is invalid.');}
    if(parsed.protocol!=='https:' && !(parsed.protocol==='http:' && (parsed.hostname==='localhost'||parsed.hostname==='127.0.0.1'))) throw new Error('The CXE relay URL must use HTTPS.');
    if(parsed.username||parsed.password||parsed.search||parsed.hash) throw new Error('The configured CXE relay URL must not contain credentials, query parameters, or a fragment.');
    RELAY_URL=raw;
    return RELAY_URL;
  }

  async function relayRequest(path, body){
    var base=await ensureRelaySettings();
    try{
      return await ZAF.request({
        url:base+path,
        type:'POST',
        contentType:'application/json',
        dataType:'json',
        data:JSON.stringify(body),
        headers:{Authorization:'Bearer {{setting.relay_secret}}'},
        secure:true,
        autoRetry:false
      });
    }catch(response){
      var payload=response && response.responseJSON, info=payload && payload.error, message=info && info.message || response && response.responseText || 'The CXE relay request failed.';
      var error=new Error(message); error.status=info && info.upstreamStatus || response && response.status || 0; error.code=info && info.code || 'RELAY_ERROR'; throw error;
    }
  }

  async function listCustomRecords(objectKey){
    var out=[], cursor='';
    for(var p=0;p<MAX_PAGES;p++){
      var url='/api/v2/custom_objects/'+encodeURIComponent(objectKey)+'/records?page[size]=100'+(cursor?'&page[after]='+encodeURIComponent(cursor):'');
      var data=await zafRequest(url,'GET');
      out=out.concat(arr(data.custom_object_records));
      if(!(data.meta && data.meta.has_more && data.meta.after_cursor)) break;
      cursor=data.meta.after_cursor;
    }
    return out;
  }

  async function upsertConnection(clientRecord, fields){
    var externalId='cxe-config:'+clientRecord.id;
    var body={custom_object_record:{name:'Config connection - '+clientRecord.name,custom_object_fields:fields}};
    return zafRequest('/api/v2/custom_objects/'+CONNECTION_OBJECT+'/records?external_id='+encodeURIComponent(externalId),'PATCH',body);
  }

  async function deleteConnection(clientRecord){
    var externalId='cxe-config:'+clientRecord.id;
    return zafRequest('/api/v2/custom_objects/'+CONNECTION_OBJECT+'/records?external_id='+encodeURIComponent(externalId),'DELETE');
  }

  function connectionFailure(error){
    var status=error && error.status;
    var patch={
      cxe_last_http_status:status||null,
      cxe_last_error:safeString(error && error.message).slice(0,1500)
    };
    if(error && error.code==='CREDENTIAL_INVALID') patch.cxe_connection_status='invalid';
    if(error && error.code==='PERMISSION_DENIED') patch.cxe_connection_status='permission_issue';
    return patch;
  }

  function sanitize(value){
    var secret=/token|secret|password|authorization|credential|api[_ -]?key|client_secret/i;
    if(Array.isArray(value)) return value.map(sanitize);
    if(value && typeof value==='object'){
      var o={}; Object.keys(value).forEach(function(k){ if(!secret.test(k)) o[k]=sanitize(value[k]); }); return o;
    }
    return value;
  }

  function readableValue(v, depth){
    depth=depth||0;
    if(v==null || v==='') return '';
    if(typeof v==='string' || typeof v==='number' || typeof v==='boolean') return String(v);
    if(depth>3) return JSON.stringify(v);
    if(Array.isArray(v)) return v.map(function(x,i){return (i+1)+'. '+readableValue(x,depth+1);}).join('\n');
    return Object.keys(v).map(function(k){return k+': '+readableValue(v[k],depth+1);}).join('\n');
  }

  function itemSummary(item){
    var keys=['id','name','title','key','active','position','type','default','created_at','updated_at'];
    var pairs=[];
    keys.forEach(function(k){ if(item && item[k]!==undefined && item[k]!==null && item[k]!=='') pairs.push([k,item[k]]); });
    return pairs;
  }

  function markdownForSection(clientName,label,items){
    var lines=['# Zendesk Configuration','','Client: '+clientName,'Section: '+label,'Captured: '+nowIso(),''];
    arr(items).forEach(function(item){
      lines.push('## '+objectName(item));
      Object.keys(sanitize(item||{})).forEach(function(k){
        var val=readableValue(sanitize(item[k]));
        if(val) lines.push('**'+k+'**: '+val.replace(/\n/g,'\n  '));
      });
      lines.push('');
    });
    return lines.join('\n');
  }

  function csvEscape(v){ var s=typeof v==='string'?v:JSON.stringify(v==null?'':v); return /[",\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s; }
  function sectionToCsv(items){
    items=arr(items); if(!items.length) return '';
    var keys=[]; items.forEach(function(x){Object.keys(x||{}).forEach(function(k){if(keys.indexOf(k)<0)keys.push(k);});});
    return keys.map(csvEscape).join(',')+'\n'+items.map(function(x){return keys.map(function(k){return csvEscape(x[k]);}).join(',');}).join('\n');
  }

  function downloadText(filename,text,type){
    var blob=new Blob([text],{type:type||'text/plain;charset=utf-8'}), url=URL.createObjectURL(blob), a=document.createElement('a');
    a.href=url; a.download=filename; document.body.appendChild(a); a.click(); a.remove(); setTimeout(function(){URL.revokeObjectURL(url);},1000);
  }

  async function copyText(text){
    if(navigator.clipboard && navigator.clipboard.writeText) return navigator.clipboard.writeText(text);
    var ta=document.createElement('textarea'); ta.value=text; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove();
  }

  function statusInfo(connection){
    if(!connection) return {label:'Not connected',color:'gray'};
    var f=connection.custom_object_fields||{};
    if(f.cxe_enabled===false || f.cxe_enabled==='false') return {label:'Disabled',color:'amber'};
    var s=safeString(f.cxe_connection_status).toLowerCase();
    if(s.indexOf('invalid')>=0 || s.indexOf('auth')>=0 && s.indexOf('fail')>=0) return {label:'Credential invalid',color:'red'};
    if(s.indexOf('permission')>=0 || s.indexOf('error')>=0) return {label:'Attention',color:'amber'};
    if(s==='connected' || s==='healthy') return {label:'Connected',color:'green'};
    return {label:safeString(f.cxe_connection_status)||'Connected',color:'blue'};
  }

  function Modal(props){
    return h('div',{className:'modal-backdrop',onMouseDown:function(e){if(e.target===e.currentTarget)props.onClose();}},
      h('div',{className:'modal'},
        h('div',{className:'modal-head'},h('div',{className:'modal-title'},props.title),h('button',{className:'close',onClick:props.onClose,'aria-label':'Close dialog'},'×')),
        h('div',{className:'modal-body'},props.children),
        props.footer?h('div',{className:'modal-foot'},props.footer):null));
  }

  function ClientList(props){
    return h('aside',{className:'sidebar'},
      h('input',{className:'search',placeholder:'Search clients…',value:props.filter,onChange:function(e){props.onFilter(e.target.value);}}),
      h('div',{className:'client-list'},props.clients.map(function(c){
        var si=statusInfo(props.connections[c.id]);
        return h('button',{key:c.id,className:'client-card'+(props.selected===c.id?' active':''),onClick:function(){props.onSelect(c.id);}},
          h('span',{className:'client-name',title:c.name},c.name),
          h('span',{className:'status-label'},h('span',{className:'status-dot '+si.color}),si.label));
      })));
  }

  function Overview(props){
    var data=props.data||{}, defs=props.defs;
    var cards=defs.map(function(d){return h('div',{className:'stat',key:d.key},h('div',{className:'stat-value'},arr(data[d.key]).length),h('div',{className:'stat-label'},d.label));});
    return h('div',null,
      h('div',{className:'stats'},cards),
      h('div',{className:'panel'},h('div',{className:'panel-head'},h('div',{className:'panel-title'},'Current sync summary')),
        h('div',{className:'panel-body'},
          props.progress?h('div',{className:'notice'},h('span',{className:'spinner'}),props.progress):null,
          h('div',{className:'help'},'Configuration lives only in the current app session. No snapshot or ticket data is stored. Use Copy or Export when you need to move the current configuration into an LLM or working document.'))));
  }

  function SectionView(props){
    var items=arr(props.items), q=(props.search||'').toLowerCase();
    var filtered=q?items.filter(function(x){try{return JSON.stringify(x).toLowerCase().indexOf(q)>=0;}catch(e){return false;}}):items;
    return h('div',{className:'panel'},
      h('div',{className:'panel-head'},
        h('div',null,h('div',{className:'panel-title'},props.label+' ('+items.length+')'),props.error?h('div',{className:'help',style:{color:'#b4232f'}},props.error):null),
        h('div',{className:'button-row'},
          h('input',{className:'search section-search',placeholder:'Search this section…',value:props.search||'',onChange:function(e){props.onSearch(e.target.value);}}),
          h('button',{className:'btn',onClick:props.onRefresh,disabled:props.busy},'Refresh'),
          h('button',{className:'btn',onClick:function(){props.onCopy('md');}},'Copy Markdown / AI'),
          h('button',{className:'btn',onClick:function(){props.onCopy('json');}},'Copy JSON'),
          h('button',{className:'btn',onClick:function(){props.onExport('csv');}},'CSV'),
          h('button',{className:'btn',onClick:function(){props.onExport('json');}},'JSON'))),
      h('div',{className:'panel-body'},
        filtered.length===0?h('div',{className:'empty'},h('h3',null,'No configuration records'),h('div',null,q?'Nothing matches this search.':'Zendesk returned no records for this area.')):
        h('div',null,filtered.slice(0,500).map(function(item,idx){
          var clean=sanitize(item||{});
          return h('details',{className:'record',key:(item.id||item.key||idx)},
            h('summary',{className:'record-summary'},h('span',{className:'record-title'},objectName(item)),h('span',{className:'record-meta'},item.id?'ID '+item.id:'Record '+(idx+1))),
            h('div',{className:'kv'},Object.keys(clean).map(function(key){
              return [h('div',{className:'kv-key',key:key+'k'},key),h('pre',{className:'kv-val record-value',key:key+'v'},readableValue(clean[key]))];
            }))
          );
        }),filtered.length>500?h('div',{className:'notice warning'},'Showing first 500 matching records. Export JSON for the complete section.'):null)));
  }

  function SetupView(props){
    return h('div',{className:'panel'},
      h('div',{className:'panel-head'},h('div',{className:'panel-title'},'Setup / Repair'),h('button',{className:'btn primary',onClick:props.onRepair,disabled:props.busy},props.busy?'Checking…':'Run Setup / Repair')),
      h('div',{className:'panel-body'},
        h('div',{className:'notice'},'Normal installs provision the app-owned custom object from requirements.json. Repair is idempotent: it verifies stable keys and only creates missing app-owned resources. It never deletes connection data.'),
        h('div',{className:'setup-list'},(props.checks||[]).map(function(x){return h('div',{className:'setup-row',key:x.label},h('span',null,x.label),h('strong',{className:x.ok?'setup-ok':'setup-bad'},x.ok?'OK':x.detail||'Missing'));})),
        props.lastResult?h('div',{className:props.lastResult.ok?'notice success':'notice error',style:{marginTop:'14px'}},props.lastResult.message):null));
  }

  function ConnectionModal(props){
    var c=props.connection&&props.connection.custom_object_fields||{};
    var isReplace=!!props.connection;
    return h(Modal,{title:(isReplace?'Replace':'Connect')+' Zendesk credential',onClose:props.onClose,footer:[h('button',{className:'btn',key:'cancel',onClick:props.onClose},'Cancel'),h('button',{className:'btn primary',key:'save',onClick:props.onSubmit,disabled:props.busy},props.busy?'Testing…':'Test & '+(isReplace?'Replace':'Connect'))]},
      h('div',{className:'notice success'},'The API token is tested by the CXE Node relay. The relay returns an encrypted credential envelope for Zendesk storage; the raw token is not saved in the connection record.'),
      h('div',{className:'grid'},
        h('div',{className:'field'},h('label',{htmlFor:'connection-domain'},'Zendesk domain'),h('input',{id:'connection-domain',value:props.form.domain,onChange:function(e){props.set('domain',e.target.value);},placeholder:'client.zendesk.com'})),
        h('div',{className:'field'},h('label',{htmlFor:'connection-email'},'Zendesk API email'),h('input',{id:'connection-email',type:'email',value:props.form.email,onChange:function(e){props.set('email',e.target.value);},placeholder:'admin@example.com'})),
        h('div',{className:'field',style:{gridColumn:'1 / -1'}},h('label',{htmlFor:'connection-token'},'Zendesk API token'),h('input',{id:'connection-token',type:'password',value:props.form.token,onChange:function(e){props.set('token',e.target.value);},autoComplete:'new-password',placeholder:'Paste Zendesk API token'}),h('div',{className:'help'},'The relay tests the email/token pair against /api/v2/users/me.json before replacing the saved encrypted envelope.'))));
  }

  class App extends React.Component {
    constructor(props){
      super(props);
      this.state={clients:[],connections:{},selected:null,filter:'',loading:true,busy:false,error:'',toast:'',tab:'overview',sectionSearch:'',syncData:{},syncErrors:{},progress:'',modal:null,connectionForm:{domain:'',email:'',token:''},checks:[],setupResult:null,currentUser:null};
      this.load=this.load.bind(this); this.selectClient=this.selectClient.bind(this); this.syncAll=this.syncAll.bind(this); this.syncSection=this.syncSection.bind(this); this.runRepair=this.runRepair.bind(this);
    }
    componentDidMount(){ this.load(); }
    notify(msg){ var self=this; this.setState({toast:msg}); if(ZAF) try{ZAF.invoke('notify',msg);}catch(ignore){} setTimeout(function(){if(self.state.toast===msg)self.setState({toast:''});},3200); }
    async load(){
      this.setState({loading:true,error:''});
      try{
        await ensureRelaySettings();
        var user=null; try{var ud=await ZAF.get('currentUser'); user=ud.currentUser;}catch(ignore){}
        var results=await Promise.all([listCustomRecords(CLIENT_OBJECT),listCustomRecords(CONNECTION_OBJECT).catch(function(){return [];})]);
        var clients=results[0].sort(function(a,b){return safeString(a.name).localeCompare(safeString(b.name));}), conns={};
        results[1].forEach(function(r){var id=r.custom_object_fields&&r.custom_object_fields.cxe_client;if(id)conns[id]=r;});
        this.setState({clients:clients,connections:conns,selected:this.state.selected||(clients[0]&&clients[0].id),loading:false,currentUser:user});
        this.verifySchema();
      }catch(e){ this.setState({loading:false,error:e.message||String(e)}); }
    }
    async verifySchema(){
      var checks=[];
      try{await zafRequest('/api/v2/custom_objects/'+CLIENT_OBJECT,'GET');checks.push({label:'Existing client object',ok:true});}catch(e){checks.push({label:'Existing client object',ok:false,detail:'Missing'});}
      try{
        await zafRequest('/api/v2/custom_objects/'+CONNECTION_OBJECT,'GET'); checks.push({label:'CXE connection object',ok:true});
        var fd=await zafRequest('/api/v2/custom_objects/'+CONNECTION_OBJECT+'/fields','GET'); var found={}; arr(fd.custom_object_fields).forEach(function(x){found[x.key]=x;});
        REQUIRED_FIELDS.forEach(function(x){
          var actual=found[x.key], expected=expectedFieldType(x), received=expectedFieldType(actual), ok=!!actual && received===expected;
          checks.push({label:'Field '+x.key,ok:ok,detail:actual?'Expected '+expected+', found '+received:'Missing'});
        });
      }catch(e){ checks.push({label:'CXE connection object',ok:false,detail:'Missing'}); }
      this.setState({checks:checks}); return checks;
    }
    async runRepair(){
      this.setState({busy:true,setupResult:null});
      try{
        var isAdmin=this.state.currentUser && (this.state.currentUser.role==='admin' || this.state.currentUser.role==='account_owner');
        var exists=true; try{await zafRequest('/api/v2/custom_objects/'+CONNECTION_OBJECT,'GET');}catch(e){exists=false;}
        if(!exists){
          if(!isAdmin) throw new Error('The app-owned custom object is missing. An administrator must run Setup / Repair or reinstall the package so requirements.json can provision it.');
          await zafRequest('/api/v2/custom_objects','POST',{custom_object:{key:CONNECTION_OBJECT,title:'CXE Zendesk Config Connection',title_pluralized:'CXE Zendesk Config Connections',include_in_list_view:false}});
        }
        var fd=await zafRequest('/api/v2/custom_objects/'+CONNECTION_OBJECT+'/fields','GET'); var found={}; arr(fd.custom_object_fields).forEach(function(x){found[x.key]=x;});
        if(isAdmin){
          for(var i=0;i<REQUIRED_FIELDS.length;i++){
            var spec=REQUIRED_FIELDS[i]; if(found[spec.key]) continue;
            await zafRequest('/api/v2/custom_objects/'+CONNECTION_OBJECT+'/fields','POST',{custom_object_field:spec});
          }
        }
        var checks=await this.verifySchema(); var bad=checks.filter(function(x){return !x.ok;});
        if(bad.length) throw new Error('Schema still has '+bad.length+' issue(s). '+(!isAdmin?'Ask an administrator to run repair.':'Review the failed fields.'));
        this.setState({setupResult:{ok:true,message:'Schema is healthy. Existing records were preserved and no destructive changes were made.'}}); this.notify('Setup / Repair completed.'); await this.load();
      }catch(e){this.setState({setupResult:{ok:false,message:e.message||String(e)}});} finally{this.setState({busy:false});}
    }
    selectedClient(){return this.state.clients.find(function(c){return c.id===this.state.selected;}.bind(this));}
    selectedConnection(){return this.state.connections[this.state.selected];}
    selectClient(id){this.setState({selected:id,tab:'overview',sectionSearch:'',syncData:{},syncErrors:{},progress:''});}
    openConnect(){var conn=this.selectedConnection(), f=conn&&conn.custom_object_fields||{};this.setState({modal:'connect',connectionForm:{domain:f.cxe_domain||'',email:f.cxe_api_email||'',token:''}});}
    async submitConnection(){
      var clientRec=this.selectedClient(), form=this.state.connectionForm; if(!clientRec)return;
      this.setState({busy:true,error:''});
      try{
        var domain=normalizeDomain(form.domain); if(!form.email)throw new Error('Enter the Zendesk API email.'); if(!form.token)throw new Error('Enter a Zendesk API token.');
        var test=await relayRequest('/v1/connections/test-and-seal',{clientId:clientRec.id,domain:domain,email:form.email,apiToken:form.token});
        var existing=this.selectedConnection(), old=existing&&existing.custom_object_fields||{};
        var fields={cxe_client:clientRec.id,cxe_domain:domain,cxe_api_email:form.email.trim(),cxe_auth_type:'api_token',cxe_credential_envelope:test.credentialEnvelope,cxe_enabled:true,cxe_connection_status:'connected',cxe_last_test_at:test.testedAt||nowIso(),cxe_last_sync_at:old.cxe_last_sync_at||'',cxe_last_http_status:test.httpStatus||200,cxe_last_error:'',cxe_credential_updated_at:nowIso(),cxe_auth_version:TOKEN_STORAGE_VERSION};
        await upsertConnection(clientRec,fields); this.setState({modal:null,connectionForm:{domain:'',email:'',token:''}}); await this.load(); this.notify('Connection tested and encrypted credential saved.');
      }catch(e){this.setState({error:e.message||String(e)});} finally{this.setState({busy:false});}
    }
    async getRelayConnection(){
      var conn=this.selectedConnection(); if(!conn)throw new Error('Connect this client first.'); var f=conn.custom_object_fields||{};
      if(f.cxe_enabled===false || f.cxe_enabled==='false')throw new Error('This connection is disabled.');
      if(!f.cxe_credential_envelope)throw new Error('This connection uses an older credential format. Replace the credential once to use the Node relay.');
      return {clientId:this.state.selected,domain:normalizeDomain(f.cxe_domain),email:f.cxe_api_email,credentialEnvelope:f.cxe_credential_envelope};
    }
    async updateConnectionFields(patch){
      var clientRec=this.selectedClient(), conn=this.selectedConnection(); if(!clientRec||!conn)return; var f=Object.assign({},conn.custom_object_fields||{},patch); await upsertConnection(clientRec,f); await this.load();
    }
    async toggleEnabled(){
      var conn=this.selectedConnection(); if(!conn)return; var f=conn.custom_object_fields||{}, enabled=!(f.cxe_enabled===false||f.cxe_enabled==='false');
      this.setState({busy:true}); try{await this.updateConnectionFields({cxe_enabled:!enabled,cxe_connection_status:!enabled?'connected':'disabled'});this.notify(!enabled?'Connection enabled.':'Connection disabled.');}catch(e){this.setState({error:e.message});}finally{this.setState({busy:false});}
    }
    async removeConnection(){
      var clientRec=this.selectedClient(); if(!clientRec)return; if(!confirm('Remove the saved connection for '+clientRec.name+'? The Client record is not deleted.'))return;
      this.setState({busy:true}); try{await deleteConnection(clientRec);this.setState({syncData:{}});await this.load();this.notify('Connection removed.');}catch(e){this.setState({error:e.message});}finally{this.setState({busy:false});}
    }
    async testConnection(){
      var conn=this.selectedConnection(); if(!conn)return; this.setState({busy:true,error:''});
      try{var connection=await this.getRelayConnection(), r=await relayRequest('/v1/connections/test',{connection:connection});await this.updateConnectionFields({cxe_connection_status:'connected',cxe_last_test_at:r.testedAt||nowIso(),cxe_last_http_status:r.httpStatus||200,cxe_last_error:''});this.notify('Connection test successful.');}
      catch(e){try{await this.updateConnectionFields(Object.assign({cxe_last_test_at:nowIso()},connectionFailure(e)));}catch(ignore){} this.setState({error:e.message});}
      finally{this.setState({busy:false});}
    }
    async syncAll(){
      var conn=this.selectedConnection(), clientRec=this.selectedClient(); if(!conn||!clientRec)return; this.setState({busy:true,error:'',syncErrors:{},progress:'Preparing sync…'});
      try{
        var connection=await this.getRelayConnection(), sectionKeys=SOURCE_DEFS.concat(GENERATED_DEFS).map(function(d){return d.key;}), result=await relayRequest('/v1/sync',{connection:connection,sections:sectionKeys}), data=result.data||{}, errors=result.errors||{};
        var errorKeys=Object.keys(errors), summary=errorKeys.length?errorKeys.length+' section(s) could not be read: '+errorKeys.join(', '):'';
        await this.updateConnectionFields({cxe_connection_status:'connected',cxe_last_sync_at:result.syncedAt||nowIso(),cxe_last_test_at:nowIso(),cxe_last_http_status:200,cxe_last_error:summary});
        this.setState({syncData:data,syncErrors:errors,progress:'',tab:'overview'}); this.notify('Configuration sync completed.');
      }catch(e){try{await this.updateConnectionFields(connectionFailure(e));}catch(ignore){}this.setState({progress:'',error:e.message||String(e)});} finally{this.setState({busy:false});}
    }
    async syncSection(key){
      var d=sectionDef(key); if(!d)return; var conn=this.selectedConnection(); this.setState({busy:true,error:'',progress:'Syncing '+d.label+'…'});
      try{
        var connection=await this.getRelayConnection(), result=await relayRequest('/v1/sync',{connection:connection,sections:[key]}), items=result.data&&result.data[key]||[], data=Object.assign({},this.state.syncData);
        data[key]=items;var errs=Object.assign({},this.state.syncErrors);delete errs[key];this.setState({syncData:data,syncErrors:errs,progress:''});
        await this.updateConnectionFields({cxe_connection_status:'connected',cxe_last_sync_at:nowIso(),cxe_last_http_status:200,cxe_last_error:''});this.notify(d.label+' refreshed.');
      }
      catch(e){try{await this.updateConnectionFields(connectionFailure(e));}catch(ignore){}var er=Object.assign({},this.state.syncErrors);er[key]=e.message;this.setState({syncErrors:er,progress:'',error:e.message});} finally{this.setState({busy:false});}
    }
    async copySection(kind){
      var clientRec=this.selectedClient(), key=this.state.tab, d=sectionDef(key); if(!d)return; var items=this.state.syncData[key]||[];
      var text=kind==='json'?JSON.stringify(sanitize(items),null,2):markdownForSection(clientRec.name,d.label,items); await copyText(text);this.notify(kind==='json'?'JSON copied.':'LLM-friendly Markdown copied.');
    }
    exportSection(kind){
      var clientRec=this.selectedClient(), key=this.state.tab, d=sectionDef(key); if(!d)return;var items=this.state.syncData[key]||[],base=clientRec.name.toLowerCase().replace(/[^a-z0-9]+/g,'-')+'-'+key;
      if(kind==='csv')downloadText(base+'.csv',sectionToCsv(items),'text/csv;charset=utf-8');else downloadText(base+'.json',JSON.stringify(sanitize(items),null,2),'application/json');
    }
    async copyWhole(){var c=this.selectedClient(); if(!c)return; var clean=sanitize(this.state.syncData);await copyText('# Zendesk Configuration\n\nClient: '+c.name+'\nCaptured: '+nowIso()+'\n\n```json\n'+JSON.stringify(clean,null,2)+'\n```');this.notify('Whole configuration copied for AI.');}
    exportWhole(){var c=this.selectedClient();if(!c)return;downloadText(c.name.toLowerCase().replace(/[^a-z0-9]+/g,'-')+'-zendesk-config.json',JSON.stringify(sanitize(this.state.syncData),null,2),'application/json');}
    render(){
      var self=this, s=this.state, clients=s.clients.filter(function(c){return safeString(c.name).toLowerCase().indexOf(s.filter.toLowerCase())>=0;}), selected=this.selectedClient(), conn=this.selectedConnection(), cf=conn&&conn.custom_object_fields||{}, si=statusInfo(conn);
      var configDefs=SOURCE_DEFS.concat(GENERATED_DEFS), allTabs=[{key:'overview',label:'Overview'}].concat(configDefs.map(function(d){return {key:d.key,label:d.label};}));
      allTabs.push({key:'setup',label:'Setup / Repair'});
      var currentDef=sectionDef(s.tab);
      return h('div',{className:'shell'},
        h('header',{className:'topbar'},h('div',{className:'brand'},h('div',{className:'brand-mark'},'CX'),h('div',null,h('div',{className:'brand-title'},'Zendesk Config Sync'),h('div',{className:'brand-sub'},'CX Experts · read-only configuration intelligence'))),h('div',{className:'top-actions'},h('span',{className:'badge muted'},s.currentUser?s.currentUser.name:'Zendesk session'),h('button',{className:'btn',onClick:function(){self.setState({tab:'setup'});}},'Setup / Repair'),h('button',{className:'btn',onClick:function(){self.load();}},'Reload clients'))),
        h('div',{className:'content'},
          h(ClientList,{clients:clients,connections:s.connections,selected:s.selected,filter:s.filter,onFilter:function(v){self.setState({filter:v});},onSelect:this.selectClient}),
          h('main',{className:'main'},
            s.loading?h('div',{className:'empty'},h('span',{className:'spinner'}),'Loading Zendesk clients…'):
            s.error&&!selected?h('div',{className:'notice error'},s.error):
            !selected?h('div',{className:'empty'},h('h3',null,'No client selected'),h('div',null,'Select a Client record from the left.')):
            h('div',null,
              h('div',{className:'page-head'},h('div',null,h('h1',{className:'page-title'},selected.name),h('div',{className:'page-meta'},h('span',{className:'status-dot '+si.color}), ' '+si.label+(cf.cxe_domain?' · '+cf.cxe_domain:'')+(cf.cxe_last_sync_at?' · Last sync '+humanTime(cf.cxe_last_sync_at):''))),
                h('div',{className:'button-row'},
                  !conn?h('button',{className:'btn primary',onClick:function(){self.openConnect();}},'Connect Zendesk'):null,
                  conn?h('button',{className:'btn primary',onClick:this.syncAll,disabled:s.busy||cf.cxe_enabled===false||cf.cxe_enabled==='false'},s.busy?h('span',null,h('span',{className:'spinner'}),'Working…'):'Sync all'):null,
                  conn?h('button',{className:'btn',onClick:function(){self.testConnection();},disabled:s.busy},'Test'):null,
                  conn?h('button',{className:'btn',onClick:function(){self.openConnect();},disabled:s.busy},'Replace credential'):null,
                  conn?h('button',{className:'btn',onClick:function(){self.toggleEnabled();},disabled:s.busy},(cf.cxe_enabled===false||cf.cxe_enabled==='false')?'Enable':'Disable'):null,
                  conn?h('button',{className:'btn danger',onClick:function(){self.removeConnection();},disabled:s.busy},'Remove'):null)),
              s.error?h('div',{className:'notice error'},s.error,h('button',{className:'close',style:{float:'right'},onClick:function(){self.setState({error:''});}},'×')):null,
              conn?h('div',{className:'tabs'},allTabs.map(function(t){return h('button',{key:t.key,className:'tab'+(s.tab===t.key?' active':''),onClick:function(){self.setState({tab:t.key,sectionSearch:''});}},t.label);})):null,
              s.tab==='setup'?h(SetupView,{checks:s.checks,lastResult:s.setupResult,busy:s.busy,onRepair:this.runRepair}):
              !conn?h('div',{className:'panel'},h('div',{className:'panel-body empty'},h('h3',null,'Not connected'),h('div',null,'This Client record exists in CX Zendesk but has no Config Sync connection yet.'),h('div',{className:'footer-note'},'Connect it with a Zendesk API email and token. The Node relay retrieves configuration only; no ticket data is retrieved.'))):
              s.tab==='overview'?h('div',null,h('div',{className:'button-row',style:{marginBottom:'12px'}},h('button',{className:'btn',onClick:function(){self.copyWhole();},disabled:!Object.keys(s.syncData).length},'Copy whole config for AI'),h('button',{className:'btn',onClick:function(){self.exportWhole();},disabled:!Object.keys(s.syncData).length},'Export whole JSON')),h(Overview,{data:s.syncData,defs:configDefs,progress:s.progress})):
              currentDef?h(SectionView,{label:currentDef.label,items:s.syncData[s.tab]||[],error:s.syncErrors[s.tab],search:s.sectionSearch,onSearch:function(v){self.setState({sectionSearch:v});},busy:s.busy,onRefresh:function(){self.syncSection(s.tab);},onCopy:function(k){self.copySection(k);},onExport:function(k){self.exportSection(k);}}):null
            ))),
        s.modal==='connect'?h(ConnectionModal,{connection:conn,form:s.connectionForm,busy:s.busy,onClose:function(){self.setState({modal:null,error:''});},set:function(k,v){var f=Object.assign({},s.connectionForm);f[k]=v;self.setState({connectionForm:f});},onSubmit:function(){self.submitConnection();}}):null,
        s.toast?h('div',{className:'toast'},s.toast):null);
    }
  }

  if(!window.React || !window.ReactDOM){ document.getElementById('root').innerHTML='<div style="padding:24px;font-family:sans-serif">React runtime could not be loaded.</div>'; return; }
  ReactDOM.createRoot(document.getElementById('root')).render(h(App));
})();
