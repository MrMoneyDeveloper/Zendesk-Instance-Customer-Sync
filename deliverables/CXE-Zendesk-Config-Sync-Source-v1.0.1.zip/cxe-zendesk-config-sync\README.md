# CX Experts Zendesk Configuration Sync

Private, read-only Zendesk Support app for `pdi-cx-experts.zendesk.com`.

## What this build is

This is a **client-side Zendesk app**. The installable ZIP contains the React runtime, application JavaScript, CSS, icons, `manifest.json`, and `requirements.json`. Zendesk hosts these assets and opens the app in the Support navigation bar.

Node.js is the local development, test, and ZCLI packaging toolchain. **There is no Node/Express production server in this design.**

## Runtime architecture

1. The app uses `ZAFClient.init()` inside CX Experts Zendesk.
2. The existing custom object `client` is the authoritative client directory.
3. `requirements.json` provisions the app-owned `cxe_zd_sync_connection` object.
4. Connection records use a lookup field to `zen:custom_object:client` and deterministic external id `cxe-config:{CLIENT_RECORD_ID}`.
5. The app reads the selected client's Zendesk configuration directly from that client's Zendesk instance.
6. Current configuration is kept in browser memory only. It is not backed up or snapshotted.
7. Users can inspect tabs, copy LLM-friendly Markdown, copy JSON, and export CSV/JSON.

## Important authentication constraint

A single Zendesk-hosted ZIP cannot securely use a stored Zendesk API token to call a **different** Zendesk Support instance. Zendesk's browser CORS support for its APIs requires OAuth access tokens, and ZAF `client.request()` cannot proxy calls into another Zendesk instance.

Therefore this self-contained POC uses **OAuth access tokens** for client instances.

### Credential storage

The OAuth token is encrypted with Web Crypto before it is stored in `cxe_zd_sync_connection.cxe_credential_envelope`:

- PBKDF2-SHA256, 210,000 iterations
- unique 128-bit salt per connection
- AES-256-GCM
- unique 96-bit IV per connection
- additional authenticated data binds ciphertext to the Client record and Zendesk domain

The **CXE vault passphrase is never stored** in Zendesk, the app ZIP, localStorage, or sessionStorage. An authorised team member enters it once per app session. Keeping an automatic decryption key inside the static app bundle would make the encryption recoverable by anyone who can inspect the app code, so this build deliberately does not do that.

For a future no-passphrase experience, use a proper server-side secret store or a more complex Zendesk Integration Services (ZIS) design. Do not hard-code an AES key in the app.

## App-owned custom object

`cxe_zd_sync_connection`

Fields:

- `cxe_client` lookup → `client`
- `cxe_domain`
- `cxe_api_email`
- `cxe_auth_type`
- `cxe_credential_envelope`
- `cxe_enabled`
- `cxe_connection_status`
- `cxe_last_test_at`
- `cxe_last_sync_at`
- `cxe_last_http_status`
- `cxe_last_error`
- `cxe_credential_updated_at`
- `cxe_auth_version`

The app never uses the existing `client.api_key__conversation_and_other_` field as its credential store.

## Schema upgrades

Stable object and field **keys** are the contract. Installation/update uses `requirements.json`; runtime **Setup / Repair** additionally verifies the schema and, for admins, creates only missing app-owned resources.

Repair is intentionally additive/idempotent. It does not delete or recreate existing connection records or fields.

## Supported config sync

The POC pulls configuration only:

- Groups
- Views
- Agents
- Inbound channels
- Operating hours
- Custom objects
- Custom-object fields
- Ticket forms
- Ticket fields
- Tags
- Custom statuses
- SLA policies
- Automations
- Triggers
- Trigger categories
- Macros
- Brands
- User fields
- Organisation fields
- Help Centre categories/sections/articles

It does **not** retrieve ticket lists, comments, requesters, ticket audits, or customer conversations.

## Development

Requires Node.js 20+.

```powershell
npm install
npm run build
npm test
npm run validate:local
```

For Zendesk's official validator/package flow:

```powershell
npm run zendesk:validate
npm run zendesk:package
```

Or install directly with the active ZCLI profile:

```powershell
npm run zendesk:create
```

## Manual upload to CX Experts

A ready-to-upload ZIP is included separately as `CXE-Zendesk-Config-Sync-POC-v1.0.1.zip`.

In `pdi-cx-experts.zendesk.com`:

1. Admin Center → Apps and integrations → Apps → Zendesk Support apps.
2. Upload App.
3. Select `CXE-Zendesk-Config-Sync-POC-v1.0.1.zip`.
4. Enable the appropriate **role/group restrictions** for the internal CX Experts users who should access it.
5. Install.
6. Open **CXE Zendesk Config Sync** from the Support navigation bar.
7. Open **Setup / Repair** and verify every schema check is green.
8. Connect a test client with a Zendesk OAuth access token and the agreed internal CXE vault passphrase.
9. Test connection before running a full sync.

## OAuth setup for the POC

The app currently accepts an OAuth access token during **Connect/Replace credential**. It tests the token against `/api/v2/users/me.json` before changing the stored encrypted credential.

A later version can add full authorization-code + PKCE onboarding after the CX Experts team settles the OAuth client/redirect strategy across managed client Zendesk instances.

## Error handling

- `401`: credential invalid/expired/revoked
- `403`: permission issue (note: browser may expose this as a CORS/network error)
- `404`: optional feature unavailable
- `429`: retries when the browser receives the status; Zendesk may hide 429 behind a CORS error
- `5xx`: controlled retry/backoff
- unexpected redirect/host: blocked
- only HTTPS `*.zendesk.com` client hosts are permitted

## Files

- `zendesk-app/` — uploadable Zendesk app root
- `src/` — application source
- `vendor/` — vendored React runtime used by the self-contained ZIP
- `scripts/build.mjs` — Node build copier
- `scripts/validate.mjs` — local structural validation
- `tests/app.test.mjs` — Node automated checks

## Known POC limitation

The biggest limitation is deliberate: **no background sync**. The app synchronises only while an authorised internal user has it open and clicks Sync. That matches the current scope and avoids inventing backend infrastructure for a tool whose job is primarily “sync → inspect → copy/export”.
