# Security Notes

## Threat boundary

This is a private CX Experts Zendesk app, but being behind Zendesk login does not make secrets embedded in JavaScript secret. Every static file shipped in the ZIP can be inspected by an authorised browser session.

## Credential rule

Never store a client API/OAuth credential as plaintext in a `client` or `cxe_zd_sync_connection` record.

The current single-ZIP POC stores only an AES-GCM ciphertext envelope. The decryption passphrase is supplied in-memory by the authorised operator and is never persisted.

## Why API token mode is not active

Zendesk does not support authenticated browser CORS with Zendesk API tokens, and ZAF cannot proxy a request to another Zendesk Support instance. Cross-instance browser sync therefore uses OAuth bearer tokens.

## Outbound protection

The runtime normalises and validates client domains and allows only HTTPS hosts ending in `.zendesk.com`. Pagination is rejected if Zendesk returns a next-page URL on another host.

## Data handling

Configuration is held in memory for the current app session. No ticket corpus or snapshot database is created. Copy-for-AI and exports recursively strip keys that look like credentials, authorization headers, secrets, passwords, tokens, or API keys.
