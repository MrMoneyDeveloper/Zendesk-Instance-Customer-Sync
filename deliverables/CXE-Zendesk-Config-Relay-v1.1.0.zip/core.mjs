import { createCipheriv, createDecipheriv, timingSafeEqual, randomBytes } from 'node:crypto';

export const SECTION_DEFS = [
  { key: 'groups', path: '/api/v2/groups.json', root: 'groups' },
  { key: 'views', path: '/api/v2/views.json', root: 'views' },
  { key: 'agents', path: '/api/v2/users.json?role%5B%5D=agent&role%5B%5D=admin', root: 'users' },
  { key: 'recipient_addresses', path: '/api/v2/recipient_addresses.json', root: 'recipient_addresses' },
  { key: 'business_hours', path: '/api/v2/business_hours/schedules.json', root: 'schedules' },
  { key: 'custom_objects', path: '/api/v2/custom_objects', root: 'custom_objects', optional: true },
  { key: 'custom_object_fields', generated: 'custom_object_fields', optional: true },
  { key: 'ticket_forms', path: '/api/v2/ticket_forms.json', root: 'ticket_forms' },
  { key: 'ticket_fields', path: '/api/v2/ticket_fields.json', root: 'ticket_fields' },
  { key: 'tags', path: '/api/v2/tags.json', root: 'tags', optional: true },
  { key: 'custom_statuses', path: '/api/v2/custom_statuses.json', root: 'custom_statuses', optional: true },
  { key: 'sla_policies', path: '/api/v2/slas/policies.json', root: 'sla_policies', optional: true },
  { key: 'automations', path: '/api/v2/automations.json', root: 'automations' },
  { key: 'triggers', path: '/api/v2/triggers.json', root: 'triggers' },
  { key: 'trigger_categories', path: '/api/v2/trigger_categories', root: 'trigger_categories', optional: true },
  { key: 'macros', path: '/api/v2/macros.json', root: 'macros' },
  { key: 'brands', path: '/api/v2/brands.json', root: 'brands', optional: true },
  { key: 'user_fields', path: '/api/v2/user_fields.json', root: 'user_fields', optional: true },
  { key: 'organization_fields', path: '/api/v2/organization_fields.json', root: 'organization_fields', optional: true },
  { key: 'help_centre_categories', helpCentre: 'categories', optional: true },
  { key: 'help_centre_sections', helpCentre: 'sections', optional: true },
  { key: 'help_centre_articles', helpCentre: 'articles', optional: true }
];

const SECTION_MAP = new Map(SECTION_DEFS.map((definition) => [definition.key, definition]));
const MAX_PAGES = 100;

export class RelayError extends Error {
  constructor(message, status = 500, code = 'RELAY_ERROR', upstreamStatus) {
    super(message);
    this.status = status;
    this.code = code;
    this.upstreamStatus = upstreamStatus;
  }
}

export function normalizeDomain(value) {
  const domain = String(value ?? '').trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/$/, '').split('/')[0];
  if (!/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.zendesk\.com$/.test(domain)) {
    throw new RelayError('Enter a valid Zendesk subdomain such as client.zendesk.com.', 400, 'INVALID_INPUT');
  }
  return domain;
}

export function validateEmail(value) {
  const email = String(value ?? '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 255) {
    throw new RelayError('Enter the integration email used with this API token.', 400, 'INVALID_INPUT');
  }
  return email;
}

export function validateClientId(value) {
  const clientId = String(value ?? '').trim();
  if (!clientId || clientId.length > 128) throw new RelayError('A valid Client record id is required.', 400, 'INVALID_INPUT');
  return clientId;
}

function aad(connection) {
  return Buffer.from(`${validateClientId(connection.clientId)}|${normalizeDomain(connection.domain)}|${validateEmail(connection.email)}|api_token`, 'utf8');
}

export function sealCredential(apiToken, connection, encryptionKey, keyId = 'key01') {
  const token = String(apiToken ?? '').trim();
  if (!token || token.length > 4096) throw new RelayError('A valid Zendesk API token is required.', 400, 'INVALID_INPUT');
  if (!Buffer.isBuffer(encryptionKey) || encryptionKey.length !== 32) throw new Error('Encryption key must be exactly 32 bytes.');
  const nonce = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', encryptionKey, nonce);
  cipher.setAAD(aad(connection));
  const ciphertext = Buffer.concat([cipher.update(token, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return ['v1', keyId, nonce.toString('base64url'), ciphertext.toString('base64url'), tag.toString('base64url')].join(':');
}

export function openCredential(envelope, connection, encryptionKey, keyId = 'key01') {
  const parts = String(envelope ?? '').split(':');
  if (parts.length !== 5 || parts[0] !== 'v1' || parts[1] !== keyId) {
    throw new RelayError('The saved credential envelope is not supported. Replace the credential.', 400, 'CREDENTIAL_ENVELOPE_INVALID');
  }
  try {
    const nonce = Buffer.from(parts[2], 'base64url');
    const ciphertext = Buffer.from(parts[3], 'base64url');
    const tag = Buffer.from(parts[4], 'base64url');
    if (nonce.length !== 12 || tag.length !== 16) throw new Error('malformed');
    const decipher = createDecipheriv('aes-256-gcm', encryptionKey, nonce);
    decipher.setAAD(aad(connection));
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString('utf8');
  } catch (error) {
    if (error instanceof RelayError) throw error;
    throw new RelayError('The saved credential could not be decrypted. Replace the credential.', 400, 'CREDENTIAL_ENVELOPE_INVALID');
  }
}

export function safeSecretEqual(received, expected) {
  const left = Buffer.from(String(received ?? ''));
  const right = Buffer.from(String(expected ?? ''));
  return left.length === right.length && left.length > 0 && timingSafeEqual(left, right);
}

export function parseConnection(input) {
  const value = input && typeof input === 'object' ? input : {};
  return {
    clientId: validateClientId(value.clientId),
    domain: normalizeDomain(value.domain),
    email: validateEmail(value.email),
    credentialEnvelope: String(value.credentialEnvelope ?? '')
  };
}

export async function testApiToken(connection, apiToken, fetchImpl = fetch) {
  const response = await zendeskFetch(connection, apiToken, '/api/v2/users/me.json', fetchImpl);
  const data = await response.json();
  return { httpStatus: response.status, accountName: data?.user?.name || '', accountRole: data?.user?.role || '' };
}

export async function syncConfiguration(connection, apiToken, requestedSections, fetchImpl = fetch) {
  const requested = Array.isArray(requestedSections) && requestedSections.length
    ? [...new Set(requestedSections.map(String))]
    : SECTION_DEFS.map((definition) => definition.key);
  for (const key of requested) {
    if (!SECTION_MAP.has(key)) throw new RelayError(`Unsupported configuration section: ${key}`, 400, 'INVALID_INPUT');
  }

  const data = {};
  const errors = {};
  let customObjects;
  let helpCentreLocale;

  for (const key of requested) {
    const definition = SECTION_MAP.get(key);
    try {
      if (definition.generated === 'custom_object_fields') {
        customObjects ??= data.custom_objects || await fetchAll(connection, apiToken, '/api/v2/custom_objects', 'custom_objects', fetchImpl);
        data[key] = await fetchCustomObjectFields(connection, apiToken, customObjects, fetchImpl);
      } else if (definition.helpCentre) {
        helpCentreLocale ??= await getHelpCentreLocale(connection, apiToken, fetchImpl);
        data[key] = await fetchAll(connection, apiToken, `/api/v2/help_center/${encodeURIComponent(helpCentreLocale)}/${definition.helpCentre}.json`, definition.helpCentre, fetchImpl);
      } else {
        data[key] = await fetchAll(connection, apiToken, definition.path, definition.root, fetchImpl);
        if (key === 'custom_objects') customObjects = data[key];
      }
    } catch (error) {
      const relayError = normalizeError(error);
      if (!definition.optional || relayError.upstreamStatus === 401) throw relayError;
      data[key] = [];
      errors[key] = relayError.message;
    }
  }
  return { data, errors, syncedAt: new Date().toISOString() };
}

async function getHelpCentreLocale(connection, apiToken, fetchImpl) {
  try {
    const response = await zendeskFetch(connection, apiToken, '/api/v2/help_center/locales.json', fetchImpl);
    const data = await response.json();
    const locale = data?.default_locale || (Array.isArray(data?.locales) ? data.locales[0] : '') || 'en-us';
    return String(locale).toLowerCase();
  } catch {
    return 'en-us';
  }
}

async function fetchCustomObjectFields(connection, apiToken, objects, fetchImpl) {
  const output = [];
  for (const object of objects) {
    const key = String(object?.key ?? '');
    if (!key) continue;
    try {
      const fields = await fetchAll(connection, apiToken, `/api/v2/custom_objects/${encodeURIComponent(key)}/fields?include_standard_fields=true`, 'custom_object_fields', fetchImpl);
      for (const field of fields) output.push({ ...field, _parent_custom_object_key: key, _parent_custom_object_title: object.title || key });
    } catch (error) {
      const relayError = normalizeError(error);
      if (![403, 404].includes(relayError.upstreamStatus)) throw relayError;
    }
  }
  return output;
}

async function fetchAll(connection, apiToken, initialPath, root, fetchImpl) {
  const items = [];
  let nextUrl = new URL(initialPath, `https://${connection.domain}`);
  if (!nextUrl.searchParams.has('per_page') && !nextUrl.searchParams.has('page[size]')) nextUrl.searchParams.set('per_page', '100');

  for (let page = 0; page < MAX_PAGES && nextUrl; page += 1) {
    assertSafeZendeskUrl(nextUrl, connection.domain);
    const response = await zendeskFetch(connection, apiToken, nextUrl.toString(), fetchImpl);
    const body = await response.json();
    const collection = Array.isArray(body?.[root]) ? body[root] : [];
    items.push(...collection.map(stripUnsafeFields));
    nextUrl = nextPageUrl(body, nextUrl, connection.domain);
    if (page === MAX_PAGES - 1 && nextUrl) throw new RelayError('Zendesk pagination exceeded the safe page limit.', 502, 'UPSTREAM_ERROR');
  }
  return items;
}

function nextPageUrl(body, currentUrl, domain) {
  const supplied = body?.next_page || body?.links?.next;
  if (supplied) {
    const next = new URL(supplied, currentUrl);
    assertSafeZendeskUrl(next, domain);
    return next;
  }
  if (body?.meta?.has_more && body?.meta?.after_cursor) {
    const next = new URL(currentUrl);
    next.searchParams.set('page[after]', body.meta.after_cursor);
    return next;
  }
  return null;
}

function assertSafeZendeskUrl(url, domain) {
  if (url.protocol !== 'https:' || url.hostname !== domain) throw new RelayError('Zendesk returned an unsafe pagination URL.', 502, 'UPSTREAM_ERROR');
}

async function zendeskFetch(connection, apiToken, pathOrUrl, fetchImpl) {
  const url = new URL(pathOrUrl, `https://${connection.domain}`);
  assertSafeZendeskUrl(url, connection.domain);
  const authorization = `Basic ${Buffer.from(`${connection.email}/token:${apiToken}`).toString('base64')}`;

  for (let attempt = 1; attempt <= 4; attempt += 1) {
    let response;
    try {
      response = await fetchImpl(url, {
        method: 'GET',
        headers: { Accept: 'application/json', Authorization: authorization, 'User-Agent': 'CXE-Config-Sync-Relay/1.1' },
        redirect: 'error',
        signal: AbortSignal.timeout(20_000)
      });
    } catch {
      if (attempt === 4) throw new RelayError('The relay could not reach the client Zendesk instance.', 502, 'NETWORK_ERROR');
      await delay(250 * (2 ** (attempt - 1)));
      continue;
    }
    if (response.ok) return response;
    if ((response.status === 429 || response.status >= 500) && attempt < 4) {
      const retryAfter = Number(response.headers.get('retry-after'));
      await delay(Number.isFinite(retryAfter) && retryAfter > 0 ? Math.min(retryAfter * 1000, 30_000) : 500 * attempt);
      continue;
    }
    throw errorForStatus(response.status);
  }
  throw new RelayError('Zendesk request failed after retries.', 502, 'UPSTREAM_ERROR');
}

function errorForStatus(status) {
  if (status === 401) return new RelayError('The Zendesk API email or token is invalid, expired, or revoked.', 401, 'CREDENTIAL_INVALID', status);
  if (status === 403) return new RelayError('The Zendesk user does not have permission to read this configuration.', 403, 'PERMISSION_DENIED', status);
  if (status === 404) return new RelayError('This Zendesk feature or endpoint is unavailable.', 404, 'FEATURE_UNAVAILABLE', status);
  if (status === 429) return new RelayError('Zendesk rate-limited the configuration request.', 429, 'RATE_LIMITED', status);
  if (status >= 500) return new RelayError('Zendesk returned a temporary server error.', 502, 'UPSTREAM_ERROR', status);
  return new RelayError(`Zendesk request failed with HTTP ${status}.`, 502, 'UPSTREAM_ERROR', status);
}

function stripUnsafeFields(value) {
  if (Array.isArray(value)) return value.map(stripUnsafeFields);
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value)
      .filter(([key]) => !/(password|credential|access_token|refresh_token|api_token|authorization|client_secret)/i.test(key))
      .map(([key, child]) => [key, stripUnsafeFields(child)]));
  }
  return value;
}

export function normalizeError(error) {
  return error instanceof RelayError ? error : new RelayError('The relay could not complete the request safely.', 500, 'RELAY_ERROR');
}

function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}
