import http from 'node:http';
import { Buffer } from 'node:buffer';
import {
  RelayError,
  normalizeError,
  openCredential,
  parseConnection,
  safeSecretEqual,
  sealCredential,
  syncConfiguration,
  testApiToken
} from './core.mjs';

const port = Number(process.env.PORT || 8787);
const relaySecret = String(process.env.CXE_RELAY_SECRET || '');
const encryptionKeyId = String(process.env.CXE_ENCRYPTION_KEY_ID || 'key01');
const encryptionKey = Buffer.from(String(process.env.CXE_ENCRYPTION_KEY || ''), 'base64');

if (relaySecret.length < 24) throw new Error('CXE_RELAY_SECRET must be at least 24 characters.');
if (encryptionKey.length !== 32) throw new Error('CXE_ENCRYPTION_KEY must be a base64 value that decodes to exactly 32 bytes.');

export const server = http.createServer(async (request, response) => {
  setSecurityHeaders(response);
  if (request.method === 'GET' && request.url === '/health') {
    return sendJson(response, 200, { status: 'ok', service: 'cxe-zendesk-config-relay', version: '1.1.0' });
  }
  if (request.method !== 'POST') return sendJson(response, 404, { error: { code: 'NOT_FOUND', message: 'Not found.' } });

  try {
    authorize(request);
    const body = await readJson(request);

    if (request.url === '/v1/connections/test-and-seal') {
      const connection = parseConnection(body);
      const apiToken = String(body.apiToken || '');
      const result = await testApiToken(connection, apiToken);
      const credentialEnvelope = sealCredential(apiToken, connection, encryptionKey, encryptionKeyId);
      return sendJson(response, 200, { ...result, credentialEnvelope, testedAt: new Date().toISOString(), storageVersion: 'relay-aes-gcm-v1' });
    }

    if (request.url === '/v1/connections/test') {
      const connection = parseConnection(body.connection);
      const apiToken = openCredential(connection.credentialEnvelope, connection, encryptionKey, encryptionKeyId);
      const result = await testApiToken(connection, apiToken);
      return sendJson(response, 200, { ...result, testedAt: new Date().toISOString() });
    }

    if (request.url === '/v1/sync') {
      const connection = parseConnection(body.connection);
      const apiToken = openCredential(connection.credentialEnvelope, connection, encryptionKey, encryptionKeyId);
      const result = await syncConfiguration(connection, apiToken, body.sections);
      return sendJson(response, 200, result);
    }

    return sendJson(response, 404, { error: { code: 'NOT_FOUND', message: 'Not found.' } });
  } catch (error) {
    const normalized = normalizeError(error);
    logFailure(request.url, normalized);
    return sendJson(response, normalized.status, { error: { code: normalized.code, message: normalized.message, upstreamStatus: normalized.upstreamStatus } });
  }
});

function authorize(request) {
  const header = String(request.headers.authorization || '');
  const supplied = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!safeSecretEqual(supplied, relaySecret)) throw new RelayError('Relay authentication failed.', 401, 'RELAY_UNAUTHORIZED');
}

async function readJson(request) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > 64 * 1024) throw new RelayError('Request body is too large.', 413, 'INVALID_INPUT');
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}');
  } catch {
    throw new RelayError('Request body must be valid JSON.', 400, 'INVALID_INPUT');
  }
}

function setSecurityHeaders(response) {
  response.setHeader('Content-Type', 'application/json; charset=utf-8');
  response.setHeader('Cache-Control', 'no-store');
  response.setHeader('X-Content-Type-Options', 'nosniff');
  response.setHeader('Referrer-Policy', 'no-referrer');
  response.setHeader('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'");
}

function sendJson(response, status, payload) {
  response.statusCode = status;
  response.end(JSON.stringify(payload));
}

function logFailure(path, error) {
  process.stderr.write(`${JSON.stringify({ level: 'warn', path, code: error.code, status: error.status, upstreamStatus: error.upstreamStatus })}\n`);
}

if (process.env.NODE_ENV !== 'test') {
  server.listen(port, () => process.stdout.write(`CXE relay listening on port ${port}\n`));
}
