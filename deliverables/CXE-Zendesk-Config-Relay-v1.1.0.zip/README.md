# CXE Zendesk Config Relay

Stateless Node.js relay for the CXE Zendesk Config Sync private app.

The relay exists because browsers cannot call another Zendesk instance with API-token authentication. It tests API credentials server-side, returns an AES-256-GCM credential envelope for storage in the CXE connection custom object, and decrypts that envelope only while making allowlisted read-only configuration requests.

It has no database and does not persist credentials or configuration.

## Environment

Generate production values in PowerShell:

```powershell
$bytes = New-Object byte[] 32
[Security.Cryptography.RandomNumberGenerator]::Fill($bytes)
[Convert]::ToBase64String($bytes)

$secretBytes = New-Object byte[] 32
[Security.Cryptography.RandomNumberGenerator]::Fill($secretBytes)
[Convert]::ToBase64String($secretBytes)
```

Configure:

- `CXE_ENCRYPTION_KEY`: first generated value
- `CXE_RELAY_SECRET`: second generated value
- `CXE_ENCRYPTION_KEY_ID`: `key01`
- `PORT`: platform-provided port or `8787`

Keep the encryption key stable. If it changes, existing saved credential envelopes must be replaced.

## Run

```powershell
npm start
```

Deploy this folder to any Node 20+ HTTPS host. Configure the resulting HTTPS URL and the same relay secret in the Zendesk app installation settings.

The included `Dockerfile` is suitable for any container host. The service exposes `GET /health` for deployment health checks and listens on the platform-provided `PORT`.
