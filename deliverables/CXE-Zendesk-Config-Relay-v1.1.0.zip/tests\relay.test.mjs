import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { normalizeDomain, openCredential, safeSecretEqual, sealCredential, syncConfiguration } from '../core.mjs';

const connection = { clientId: 'client-123', domain: 'example.zendesk.com', email: 'admin@example.com' };

test('normalizes and restricts Zendesk domains', () => {
  assert.equal(normalizeDomain('https://Example.zendesk.com/'), 'example.zendesk.com');
  assert.throws(() => normalizeDomain('example.zendesk.com.evil.test'));
});

test('seals and opens an API token with connection-bound AES-GCM', () => {
  const key = randomBytes(32);
  const envelope = sealCredential('secret-api-token', connection, key);
  assert.match(envelope, /^v1:key01:/);
  assert.equal(openCredential(envelope, connection, key), 'secret-api-token');
  assert.throws(() => openCredential(envelope, { ...connection, clientId: 'different' }, key));
});

test('relay secret comparison rejects empty and mismatched values', () => {
  assert.equal(safeSecretEqual('', ''), false);
  assert.equal(safeSecretEqual('same-value', 'same-value'), true);
  assert.equal(safeSecretEqual('wrong', 'same-value'), false);
});

test('sync engine only requests allowlisted configuration paths', async () => {
  const seen = [];
  const fakeFetch = async (url) => {
    seen.push(String(url));
    return new Response(JSON.stringify({ groups: [{ id: 1, name: 'Support' }], next_page: null }), { status: 200, headers: { 'content-type': 'application/json' } });
  };
  const result = await syncConfiguration(connection, 'token', ['groups'], fakeFetch);
  assert.equal(result.data.groups.length, 1);
  assert.equal(seen.length, 1);
  assert.match(seen[0], /^https:\/\/example\.zendesk\.com\/api\/v2\/groups\.json/);
});

test('unsupported sections are rejected before making requests', async () => {
  await assert.rejects(() => syncConfiguration(connection, 'token', ['tickets'], async () => { throw new Error('should not run'); }), /Unsupported configuration section/);
});
