(function () {
  'use strict';

  var h = React.createElement;
  var ZIS_CORE = window.CXEZIS;
  var CONNECTION_OBJECT = 'cxe_zd_sync_connection';
  var CLIENT_OBJECT = 'client';
  var JOB_OBJECT = ZIS_CORE && ZIS_CORE.JOB_OBJECT || 'cxe_zd_sync_job';
  var TOKEN_STORAGE_VERSION = 'zis-basic-auth-v1';
  var MAX_PAGES = 100;
  var ZAF = window.ZAFClient ? window.ZAFClient.init() : null;

  var SOURCE_DEFS = [
    { key:'groups', label:'Groups', endpoint:'/api/v2/groups.json', root:'groups' },
    { key:'views', label:'Views', endpoint:'/api/v2/views.json', root:'views' },
    { key:'agents', label:'Agents', endpoint:'/api/v2/users.json?role%5B%5D=agent&role%5B%5D=admin', root:'users' },
    { key:'recipient_addresses', label:'Inbound Channels', endpoint:'/api/v2/recipient_addresses.json', root:'recipient_addresses' },
    { key:'business_hours', label:'Operating Hours', endpoint:'/api/v2/business_hours/schedules.json', root:'schedules' },
    { key:'custom_objects', label:'Custom Objects', endpoint:'/api/v2/custom_objects', root:'custom_objects', optional:true },
    { key:'ticket_forms', label:'Forms', endpoint:'/api/v2/ticket_forms.json', root:'ticket_forms' },
    { key:'ticket_fields', label:'Fields', endpoint:'/api/v2/ticket_fields.json', root:'ticket_fields' },
    { key:'tags', label:'Tags', endpoint:'/api/v2/tags.json', root:'tags', optional:true },
    { key:'custom_statuses', label:'Statuses', endpoint:'/api/v2/custom_statuses.json', root:'custom_statuses', optional:true },
    { key:'sla_policies', label:'SLA', endpoint:'/api/v2/slas/policies.json', root:'sla_policies', optional:true },
    { key:'automations', label:'Automations', endpoint:'/api/v2/automations.json', root:'automations' },
    { key:'triggers', label:'Triggers', endpoint:'/api/v2/triggers.json', root:'triggers' },
    { key:'trigger_categories', label:'Trigger Categories', endpoint:'/api/v2/trigger_categories', root:'trigger_categories', optional:true },
    { key:'macros', label:'Macros', endpoint:'/api/v2/macros.json', root:'macros' },
    { key:'brands', label:'Brands', endpoint:'/api/v2/brands.json', root:'brands', optional:true },
    { key:'user_fields', label:'User Fields', endpoint:'/api/v2/user_fields.json', root:'user_fields', optional:true },
    { key:'organization_fields', label:'Organization Fields', endpoint:'/api/v2/organization_fields.json', root:'organization_fields', optional:true }
  ];

  var GENERATED_DEFS = [
    { key:'custom_object_fields', label:'Custom Object Fields', generated:'custom_object_fields' },
    { key:'help_centre_categories', label:'Help Centre Categories', helpCentre:'categories' },
    { key:'help_centre_sections', label:'Help Centre Sections', helpCentre:'sections' },
    { key:'help_centre_articles', label:'Help Centre Articles', helpCentre:'articles' }
  ];

  var REQUIRED_FIELDS = [
    {key:'cxe_client',title:'Client',type:'lookup',relationship_target_type:'zen:custom_object:client'},
    {key:'cxe_domain',title:'Zendesk Domain',type:'text'},
    {key:'cxe_api_email',title:'API / Integration Email',type:'text'},
    {key:'cxe_auth_type',title:'Authentication Type',type:'dropdown',custom_field_options:[{name:'API Token in Zendesk ZIS',value:'api_token'}]},
    {key:'cxe_credential_envelope',title:'Legacy Credential Envelope',type:'textarea'},
    {key:'cxe_zis_connection_name',title:'Zendesk ZIS Connection Name',type:'text'},
    {key:'cxe_enabled',title:'Enabled',type:'checkbox'},
    {key:'cxe_connection_status',title:'Connection Status',type:'dropdown',custom_field_options:[{name:'Connected',value:'connected'},{name:'Credential invalid',value:'invalid'},{name:'Disabled',value:'disabled'},{name:'Permission issue',value:'permission_issue'},{name:'Error',value:'error'}]},
    {key:'cxe_last_test_at',title:'Last Connection Test',type:'text'},
    {key:'cxe_last_sync_at',title:'Last Successful Sync',type:'text'},
    {key:'cxe_last_http_status',title:'Last HTTP Status',type:'integer'},
    {key:'cxe_last_error',title:'Last Error',type:'textarea'},
    {key:'cxe_credential_updated_at',title:'Credential Updated At',type:'text'},
    {key:'cxe_auth_version',title:'Credential Storage Version',type:'text'}
  ];

  var REQUIRED_JOB_FIELDS = [
    {key:'cxe_job_client_id',title:'Client Record ID',type:'text'},
    {key:'cxe_job_run_id',title:'Run ID',type:'text'},
    {key:'cxe_job_scope',title:'Temporary Result Scope',type:'text'},
    {key:'cxe_job_key',title:'Configuration Section Key',type:'text'},
    {key:'cxe_job_root',title:'Response Root Key',type:'text'},
    {key:'cxe_job_url',title:'Read-only Zendesk URL',type:'text'},
    {key:'cxe_job_requested_at',title:'Requested At',type:'text'}
  ];

  function nowIso(){ return new Date().toISOString(); }
  function arr(x){ return Array.isArray(x) ? x : []; }
  function safeString(v){ return v == null ? '' : String(v); }
  function humanTime(v){ if(!v) return 'Never'; try{return new Date(v).toLocaleString();}catch(e){return v;} }
  function objectName(x){ return safeString(x && (x.name || x.title || x.raw_title || x.key || x.id)) || 'Untitled'; }

  function normalizeDomain(value){
    var s=safeString(value).trim().toLowerCase().replace(/^https?:\/\//,'').replace(/\/$/,'');
    s=s.split('/')[0];
    if(!/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.zendesk\.com$/.test(s)) throw new Error('Enter a valid Zendesk subdomain such as client.zendesk.com.');
    return s;
  }

  function sectionDef(key){
    return SOURCE_DEFS.concat(GENERATED_DEFS).find(function(def){return def.key===key;});
  }

  function expectedFieldType(field){
    if(!field) return '';
    return field.key==='cxe_client' ? field.type+'|'+safeString(field.relationship_target_type) : field.type;
  }

  function zafRequest(url, method, body){
    if(!ZAF) return Promise.reject(new Error('This operation requires the app to run inside Zendesk.'));
    var opts={url:url,type:method||'GET'};
    if(body!==undefined){ opts.contentType='application/json'; opts.data=JSON.stringify(body); }
    return ZAF.request(opts);
  }

  function sleep(milliseconds){ return new Promise(function(resolve){setTimeout(resolve,milliseconds);}); }

  function requestError(error,fallback){
    var payload=error && error.responseJSON, message=payload && (payload.message || payload.error && payload.error.message) || error && error.responseText || error && error.message || fallback || 'Zendesk request failed.';
    var result=new Error(typeof message==='string'?message:JSON.stringify(message));
    result.status=error && error.status || 0;
    return result;
  }

  async function zisIntegrationExists(){
    if(!ZIS_CORE) throw new Error('The Zendesk-hosted ZIS runtime was not loaded.');
    var path='/api/services/zis/registry/integrations', listing;
    try{listing=await zafRequest(path,'GET');}catch(error){var denied=requestError(error,'Zendesk Integration Services is unavailable.');if(denied.status===403)denied.message='Zendesk Integration Services is not enabled for this account or this user is not an administrator.';throw denied;}
    return arr(listing.integrations).some(function(item){return item.name===ZIS_CORE.INTEGRATION_KEY;});
  }

  async function ensureZisIntegration(){
    var exists=await zisIntegrationExists();
    if(!exists) await zafRequest('/api/services/zis/registry/'+encodeURIComponent(ZIS_CORE.INTEGRATION_KEY),'POST',{description:'CX Experts Zendesk configuration sync'});
    return true;
  }

  function zisMappings(records,override){
    var mapped={};
    arr(records).forEach(function(record){
      var fields=record.custom_object_fields||{}, clientId=safeString(fields.cxe_client), name=safeString(fields.cxe_zis_connection_name);
      if(clientId&&name&&fields.cxe_domain)mapped[clientId]={clientId:clientId,connectionName:name,domain:fields.cxe_domain};
    });
    if(override&&override.clientId)mapped[override.clientId]=override;
    return Object.keys(mapped).map(function(key){return mapped[key];});
  }

  async function installZisBundle(records,override){
    var mappings=zisMappings(records,override);
    if(!mappings.length)return false;
    var bundle=ZIS_CORE.buildBundle(mappings);
    await zafRequest('/api/services/zis/registry/'+encodeURIComponent(ZIS_CORE.INTEGRATION_KEY)+'/bundles','POST',bundle);
    try{
      await zafRequest('/api/services/zis/registry/job_specs/install?job_spec_name='+encodeURIComponent('zis:'+ZIS_CORE.INTEGRATION_KEY+':job_spec:'+ZIS_CORE.JOB_SPEC_NAME),'POST');
    }catch(error){if(!(error&&error.status===409))throw requestError(error,'The ZIS sync job could not be installed.');}
    return true;
  }

  async function createZisConnection(clientId,domain,email,token){
    var name=ZIS_CORE.connectionName(clientId);
    await zafRequest('/api/services/zis/integrations/'+encodeURIComponent(ZIS_CORE.INTEGRATION_KEY)+'/connections/basic_auth','POST',{
      name:name,
      username:safeString(email).trim()+'/token',
      password:safeString(token).trim(),
      allowed_domain:ZIS_CORE.normalizeDomain(domain)
    });
    return name;
  }

  async function deleteZisConnection(name){
    if(!name)return;
    try{await zafRequest('/api/services/zis/integrations/'+encodeURIComponent(ZIS_CORE.INTEGRATION_KEY)+'/connections/basic_auth/'+encodeURIComponent(name),'DELETE');}catch(error){if(!(error&&error.status===404))throw error;}
  }

  async function putRunConfig(scope,runId){
    var path='/api/services/zis/integrations/'+encodeURIComponent(ZIS_CORE.INTEGRATION_KEY)+'/configs';
    try{await zafRequest(path,'POST',{scope:scope,config:{run_id:runId,status:'pending'}});}
    catch(error){if(error&&error.status===422)await zafRequest(path+'/'+encodeURIComponent(scope),'PUT',{config:{run_id:runId,status:'pending'}});else throw requestError(error,'Could not prepare temporary ZIS result storage.');}
  }

  async function removeRunConfig(scope){
    try{await zafRequest('/api/services/zis/integrations/'+encodeURIComponent(ZIS_CORE.INTEGRATION_KEY)+'/configs/'+encodeURIComponent(scope),'DELETE');}catch(ignore){}
  }

  async function readRunConfigs(prefix){
    var url='/api/services/zis/integrations/'+encodeURIComponent(ZIS_CORE.INTEGRATION_KEY)+'/configs?filter%5Bscope%5D='+encodeURIComponent(prefix+'*')+'&page%5Bsize%5D=100';
    var response=await zafRequest(url,'GET'), output={};
    arr(response.configs).forEach(function(item){output[item.scope]=item.config||{};});
    return output;
  }

  function zisFailure(config){
    var raw='';try{raw=JSON.stringify(config&&config.error||{});}catch(ignore){raw=safeString(config&&config.error);}
    var error=new Error(/401|unauthor/i.test(raw)?'The Zendesk API email or token is invalid, expired, or revoked.':/403|forbidden/i.test(raw)?'The Zendesk user does not have permission to read this configuration.':'Zendesk ZIS could not complete the client request. '+raw.slice(0,500));
    error.status=/401|unauthor/i.test(raw)?401:/403|forbidden/i.test(raw)?403:0;
    error.code=error.status===401?'CREDENTIAL_INVALID':error.status===403?'PERMISSION_DENIED':'ZIS_ACTION_ERROR';
    return error;
  }

  async function executeZisBatch(clientId,specs){
    if(!specs.length)return[];
    if(specs.length>ZIS_CORE.MAX_BATCH_REQUESTS)throw new Error('The ZIS batch is too large.');
    var runId=(window.crypto&&window.crypto.randomUUID?window.crypto.randomUUID():Date.now().toString(36)+Math.random().toString(36).slice(2));
    var requests=specs.map(function(spec,index){return ZIS_CORE.makeRequest(clientId,runId,index,spec.key,spec.root,spec.url);});
    var prefix=ZIS_CORE.CONFIG_PREFIX+ZIS_CORE.hash(clientId)+'_'+ZIS_CORE.hash(runId)+'_', jobRecords=[];
    try{
      await Promise.all(requests.map(function(request){return putRunConfig(request.scope,runId);}));
      var created=await Promise.all(requests.map(function(request,index){
        return zafRequest('/api/v2/custom_objects/'+encodeURIComponent(JOB_OBJECT)+'/records','POST',{custom_object_record:{name:'CXE sync '+runId.slice(0,8)+' '+(index+1),custom_object_fields:{cxe_job_client_id:clientId,cxe_job_run_id:runId,cxe_job_scope:request.scope,cxe_job_key:request.key,cxe_job_root:request.root,cxe_job_url:request.url,cxe_job_requested_at:nowIso()}}});
      }));
      jobRecords=created.map(function(item){return item&&item.custom_object_record;}).filter(Boolean);
      for(var attempt=0;attempt<120;attempt++){
        var configs=await readRunConfigs(prefix), finished=requests.every(function(request){var config=configs[request.scope];return config&&config.run_id===runId&&config.status!=='pending';});
        if(finished)return requests.map(function(request,index){return {spec:specs[index],request:request,config:configs[request.scope]};});
        await sleep(1000);
      }
      throw new Error('Zendesk ZIS did not finish the configuration request within two minutes.');
    }finally{
      await Promise.all(requests.map(function(request){return removeRunConfig(request.scope);}));
      await Promise.all(jobRecords.map(function(jobRecord){return zafRequest('/api/v2/custom_objects/'+encodeURIComponent(JOB_OBJECT)+'/records/'+encodeURIComponent(jobRecord.id),'DELETE').catch(function(){});}));
    }
  }

  async function fetchZisSpecs(clientId,domain,specs,onProgress){
    var pending=specs.slice(), items={}, errors={}, raw={}, pageCounts={};
    while(pending.length){
      var batch=pending.splice(0,ZIS_CORE.MAX_BATCH_REQUESTS);
      if(onProgress)onProgress('Zendesk is reading '+batch.length+' configuration request'+(batch.length===1?'':'s')+' through ZIS…');
      var results=await executeZisBatch(clientId,batch);
      results.forEach(function(result){
        var spec=result.spec, config=result.config||{};
        if(config.status==='error'){
          var failure=zisFailure(config);
          if(!spec.optional||failure.status===401)throw failure;
          errors[spec.key]=failure.message;return;
        }
        var response=config.response||{}, values=arr(response[spec.root]).map(sanitize);
        if(spec.parentKey)values=values.map(function(value){return Object.assign({},value,{_parent_custom_object_key:spec.parentKey,_parent_custom_object_title:spec.parentTitle||spec.parentKey});});
        items[spec.key]=(items[spec.key]||[]).concat(values);raw[spec.key]=response;
        var countKey=spec.key+'|'+safeString(spec.parentKey), count=(pageCounts[countKey]||0)+1;pageCounts[countKey]=count;
        var next=ZIS_CORE.nextPage(response,spec.url,domain);
        if(next){if(count>=MAX_PAGES)throw new Error('Zendesk pagination exceeded the safe page limit.');pending.push(Object.assign({},spec,{url:next}));}
      });
    }
    return {items:items,errors:errors,raw:raw};
  }

  async function fetchConfiguration(clientId,domain,requestedKeys,onProgress){
    var requested=arr(requestedKeys), wanted={};requested.forEach(function(key){wanted[key]=true;});
    var data={}, errors={}, baseDefs=SOURCE_DEFS.filter(function(def){return wanted[def.key]||def.key==='custom_objects'&&wanted.custom_object_fields;});
    if(baseDefs.length){
      var base=await fetchZisSpecs(clientId,domain,baseDefs.map(function(def){return {key:def.key,root:def.root,url:ZIS_CORE.withPageSize(domain,def.endpoint),optional:!!def.optional};}),onProgress);
      Object.assign(data,base.items);Object.assign(errors,base.errors);
    }
    var helpDefs=GENERATED_DEFS.filter(function(def){return def.helpCentre&&wanted[def.key];});
    if(helpDefs.length){
      var localeResult=await fetchZisSpecs(clientId,domain,[{key:'__locales',root:'locales',url:ZIS_CORE.withPageSize(domain,'/api/v2/help_center/locales.json'),optional:true}],onProgress);
      var localeBody=localeResult.raw.__locales||{}, locale=safeString(localeBody.default_locale||arr(localeBody.locales)[0]||'en-us').toLowerCase();
      var help=await fetchZisSpecs(clientId,domain,helpDefs.map(function(def){return {key:def.key,root:def.helpCentre,url:ZIS_CORE.withPageSize(domain,'/api/v2/help_center/'+encodeURIComponent(locale)+'/'+def.helpCentre+'.json'),optional:true};}),onProgress);
      Object.assign(data,help.items);Object.assign(errors,help.errors);
    }
    if(wanted.custom_object_fields){
      var objects=arr(data.custom_objects), fieldSpecs=objects.filter(function(object){return object&&object.key;}).map(function(object){return {key:'custom_object_fields',root:'custom_object_fields',url:ZIS_CORE.withPageSize(domain,'/api/v2/custom_objects/'+encodeURIComponent(object.key)+'/fields?include_standard_fields=true'),optional:true,parentKey:object.key,parentTitle:object.title};});
      data.custom_object_fields=[];
      if(fieldSpecs.length){var fields=await fetchZisSpecs(clientId,domain,fieldSpecs,onProgress);data.custom_object_fields=fields.items.custom_object_fields||[];if(fields.errors.custom_object_fields)errors.custom_object_fields=fields.errors.custom_object_fields;}
    }
    if(!wanted.custom_objects)delete data.custom_objects;
    requested.forEach(function(key){if(!data[key])data[key]=[];});
    return {data:data,errors:errors,syncedAt:nowIso()};
  }

  async function listCustomRecords(objectKey){
    var out=[], cursor='';
    for(var p=0;p<MAX_PAGES;p++){
      var url='/api/v2/custom_objects/'+encodeURIComponent(objectKey)+'/records?page[size]=100'+(cursor?'&page[after]='+encodeURIComponent(cursor):'');
      var data=await zafRequest(url,'GET');
      out=out.concat(arr(data.custom_object_records));
      if(!(data.meta && data.meta.has_more && data.meta.after_cursor)) break;
      cursor=data.meta.after_cursor;
    }
    return out;
  }

  async function upsertConnection(clientRecord, fields){
    var externalId='cxe-config:'+clientRecord.id;
    var body={custom_object_record:{name:'Config connection - '+clientRecord.name,custom_object_fields:fields}};
    return zafRequest('/api/v2/custom_objects/'+CONNECTION_OBJECT+'/records?external_id='+encodeURIComponent(externalId),'PATCH',body);
  }

  async function deleteConnection(clientRecord){
    var externalId='cxe-config:'+clientRecord.id;
    return zafRequest('/api/v2/custom_objects/'+CONNECTION_OBJECT+'/records?external_id='+encodeURIComponent(externalId),'DELETE');
  }

  function connectionFailure(error){
    var status=error && error.status;
    var patch={
      cxe_last_http_status:status||null,
      cxe_last_error:safeString(error && error.message).slice(0,1500)
    };
    if(error && error.code==='CREDENTIAL_INVALID') patch.cxe_connection_status='invalid';
    if(error && error.code==='PERMISSION_DENIED') patch.cxe_connection_status='permission_issue';
    return patch;
  }

  function sanitize(value){
    var secret=/token|secret|password|authorization|credential|api[_ -]?key|client_secret/i;
    if(Array.isArray(value)) return value.map(sanitize);
    if(value && typeof value==='object'){
      var o={}; Object.keys(value).forEach(function(k){ if(!secret.test(k)) o[k]=sanitize(value[k]); }); return o;
    }
    return value;
  }

  function readableValue(v, depth){
    depth=depth||0;
    if(v==null || v==='') return '';
    if(typeof v==='string' || typeof v==='number' || typeof v==='boolean') return String(v);
    if(depth>3) return JSON.stringify(v);
    if(Array.isArray(v)) return v.map(function(x,i){return (i+1)+'. '+readableValue(x,depth+1);}).join('\n');
    return Object.keys(v).map(function(k){return k+': '+readableValue(v[k],depth+1);}).join('\n');
  }

  function itemSummary(item){
    var keys=['id','name','title','key','active','position','type','default','created_at','updated_at'];
    var pairs=[];
    keys.forEach(function(k){ if(item && item[k]!==undefined && item[k]!==null && item[k]!=='') pairs.push([k,item[k]]); });
    return pairs;
  }

  function markdownForSection(clientName,label,items){
    var lines=['# Zendesk Configuration','','Client: '+clientName,'Section: '+label,'Captured: '+nowIso(),''];
    arr(items).forEach(function(item){
      lines.push('## '+objectName(item));
      Object.keys(sanitize(item||{})).forEach(function(k){
        var val=readableValue(sanitize(item[k]));
        if(val) lines.push('**'+k+'**: '+val.replace(/\n/g,'\n  '));
      });
      lines.push('');
    });
    return lines.join('\n');
  }

  function csvEscape(v){ var s=typeof v==='string'?v:JSON.stringify(v==null?'':v); return /[",\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s; }
  function sectionToCsv(items){
    items=arr(items); if(!items.length) return '';
    var keys=[]; items.forEach(function(x){Object.keys(x||{}).forEach(function(k){if(keys.indexOf(k)<0)keys.push(k);});});
    return keys.map(csvEscape).join(',')+'\n'+items.map(function(x){return keys.map(function(k){return csvEscape(x[k]);}).join(',');}).join('\n');
  }

  function downloadText(filename,text,type){
    var blob=new Blob([text],{type:type||'text/plain;charset=utf-8'}), url=URL.createObjectURL(blob), a=document.createElement('a');
    a.href=url; a.download=filename; document.body.appendChild(a); a.click(); a.remove(); setTimeout(function(){URL.revokeObjectURL(url);},1000);
  }

  async function copyText(text){
    if(navigator.clipboard && navigator.clipboard.writeText) return navigator.clipboard.writeText(text);
    var ta=document.createElement('textarea'); ta.value=text; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove();
  }

  function statusInfo(connection){
    if(!connection) return {label:'Not connected',color:'gray'};
    var f=connection.custom_object_fields||{};
    if(f.cxe_enabled===false || f.cxe_enabled==='false') return {label:'Disabled',color:'amber'};
    var s=safeString(f.cxe_connection_status).toLowerCase();
    if(s.indexOf('invalid')>=0 || s.indexOf('auth')>=0 && s.indexOf('fail')>=0) return {label:'Credential invalid',color:'red'};
    if(s.indexOf('permission')>=0 || s.indexOf('error')>=0) return {label:'Attention',color:'amber'};
    if(s==='connected' || s==='healthy') return {label:'Connected',color:'green'};
    return {label:safeString(f.cxe_connection_status)||'Connected',color:'blue'};
  }

  function Modal(props){
    return h('div',{className:'modal-backdrop',onMouseDown:function(e){if(e.target===e.currentTarget)props.onClose();}},
      h('div',{className:'modal'},
        h('div',{className:'modal-head'},h('div',{className:'modal-title'},props.title),h('button',{className:'close',onClick:props.onClose,'aria-label':'Close dialog'},'×')),
        h('div',{className:'modal-body'},props.children),
        props.footer?h('div',{className:'modal-foot'},props.footer):null));
  }

  function ClientList(props){
    return h('aside',{className:'sidebar'},
      h('input',{className:'search',placeholder:'Search clients…',value:props.filter,onChange:function(e){props.onFilter(e.target.value);}}),
      h('div',{className:'client-list'},props.clients.map(function(c){
        var si=statusInfo(props.connections[c.id]);
        return h('button',{key:c.id,className:'client-card'+(props.selected===c.id?' active':''),onClick:function(){props.onSelect(c.id);}},
          h('span',{className:'client-name',title:c.name},c.name),
          h('span',{className:'status-label'},h('span',{className:'status-dot '+si.color}),si.label));
      })));
  }

  function Overview(props){
    var data=props.data||{}, defs=props.defs;
    var cards=defs.map(function(d){return h('div',{className:'stat',key:d.key},h('div',{className:'stat-value'},arr(data[d.key]).length),h('div',{className:'stat-label'},d.label));});
    return h('div',null,
      h('div',{className:'stats'},cards),
      h('div',{className:'panel'},h('div',{className:'panel-head'},h('div',{className:'panel-title'},'Current sync summary')),
        h('div',{className:'panel-body'},
          props.progress?h('div',{className:'notice'},h('span',{className:'spinner'}),props.progress):null,
          h('div',{className:'help'},'Configuration lives only in the current app session. No snapshot or ticket data is stored. Use Copy or Export when you need to move the current configuration into an LLM or working document.'))));
  }

  function SectionView(props){
    var items=arr(props.items), q=(props.search||'').toLowerCase();
    var filtered=q?items.filter(function(x){try{return JSON.stringify(x).toLowerCase().indexOf(q)>=0;}catch(e){return false;}}):items;
    return h('div',{className:'panel'},
      h('div',{className:'panel-head'},
        h('div',null,h('div',{className:'panel-title'},props.label+' ('+items.length+')'),props.error?h('div',{className:'help',style:{color:'#b4232f'}},props.error):null),
        h('div',{className:'button-row'},
          h('input',{className:'search section-search',placeholder:'Search this section…',value:props.search||'',onChange:function(e){props.onSearch(e.target.value);}}),
          h('button',{className:'btn',onClick:props.onRefresh,disabled:props.busy},'Refresh'),
          h('button',{className:'btn',onClick:function(){props.onCopy('md');}},'Copy Markdown / AI'),
          h('button',{className:'btn',onClick:function(){props.onCopy('json');}},'Copy JSON'),
          h('button',{className:'btn',onClick:function(){props.onExport('csv');}},'CSV'),
          h('button',{className:'btn',onClick:function(){props.onExport('json');}},'JSON'))),
      h('div',{className:'panel-body'},
        filtered.length===0?h('div',{className:'empty'},h('h3',null,'No configuration records'),h('div',null,q?'Nothing matches this search.':'Zendesk returned no records for this area.')):
        h('div',null,filtered.slice(0,500).map(function(item,idx){
          var clean=sanitize(item||{});
          return h('details',{className:'record',key:(item.id||item.key||idx)},
            h('summary',{className:'record-summary'},h('span',{className:'record-title'},objectName(item)),h('span',{className:'record-meta'},item.id?'ID '+item.id:'Record '+(idx+1))),
            h('div',{className:'kv'},Object.keys(clean).map(function(key){
              return [h('div',{className:'kv-key',key:key+'k'},key),h('pre',{className:'kv-val record-value',key:key+'v'},readableValue(clean[key]))];
            }))
          );
        }),filtered.length>500?h('div',{className:'notice warning'},'Showing first 500 matching records. Export JSON for the complete section.'):null)));
  }

  function SetupView(props){
    return h('div',{className:'panel'},
      h('div',{className:'panel-head'},h('div',{className:'panel-title'},'Setup / Repair'),h('button',{className:'btn primary',onClick:props.onRepair,disabled:props.busy},props.busy?'Checking…':'Run Setup / Repair')),
      h('div',{className:'panel-body'},
        h('div',{className:'notice'},'Normal installs provision the app-owned connection and temporary job objects from requirements.json. Repair also registers the Zendesk-hosted ZIS integration and refreshes its bundle. It is idempotent and never deletes connection data.'),
        h('div',{className:'setup-list'},(props.checks||[]).map(function(x){return h('div',{className:'setup-row',key:x.label},h('span',null,x.label),h('strong',{className:x.ok?'setup-ok':'setup-bad'},x.ok?'OK':x.detail||'Missing'));})),
        props.lastResult?h('div',{className:props.lastResult.ok?'notice success':'notice error',style:{marginTop:'14px'}},props.lastResult.message):null));
  }

  function ConnectionModal(props){
    var c=props.connection&&props.connection.custom_object_fields||{};
    var isReplace=!!props.connection;
    return h(Modal,{title:(isReplace?'Replace':'Connect')+' Zendesk credential',onClose:props.onClose,footer:[h('button',{className:'btn',key:'cancel',onClick:props.onClose},'Cancel'),h('button',{className:'btn primary',key:'save',onClick:props.onSubmit,disabled:props.busy},props.busy?'Testing…':'Test & '+(isReplace?'Replace':'Connect'))]},
      h('div',{className:'notice success'},'Zendesk stores the API token in its ZIS Connection Service and redacts it after submission. The Support app stores only the ZIS connection name; no external relay or vault passphrase is used.'),
      h('div',{className:'grid'},
        h('div',{className:'field'},h('label',{htmlFor:'connection-domain'},'Zendesk domain'),h('input',{id:'connection-domain',value:props.form.domain,onChange:function(e){props.set('domain',e.target.value);},placeholder:'client.zendesk.com'})),
        h('div',{className:'field'},h('label',{htmlFor:'connection-email'},'Zendesk API email'),h('input',{id:'connection-email',type:'email',value:props.form.email,onChange:function(e){props.set('email',e.target.value);},placeholder:'admin@example.com'})),
        h('div',{className:'field',style:{gridColumn:'1 / -1'}},h('label',{htmlFor:'connection-token'},'Zendesk API token'),h('input',{id:'connection-token',type:'password',value:props.form.token,onChange:function(e){props.set('token',e.target.value);},autoComplete:'new-password',placeholder:'Paste Zendesk API token'}),h('div',{className:'help'},'Zendesk ZIS tests the email/token pair against /api/v2/users/me.json before the saved connection is replaced.'))));
  }

  class App extends React.Component {
    constructor(props){
      super(props);
      this.state={clients:[],connections:{},selected:null,filter:'',loading:true,busy:false,error:'',toast:'',tab:'overview',sectionSearch:'',syncData:{},syncErrors:{},progress:'',modal:null,connectionForm:{domain:'',email:'',token:''},checks:[],setupResult:null,currentUser:null};
      this.load=this.load.bind(this); this.selectClient=this.selectClient.bind(this); this.syncAll=this.syncAll.bind(this); this.syncSection=this.syncSection.bind(this); this.runRepair=this.runRepair.bind(this);
    }
    componentDidMount(){ this.load(); }
    notify(msg){ var self=this; this.setState({toast:msg}); if(ZAF) try{ZAF.invoke('notify',msg);}catch(ignore){} setTimeout(function(){if(self.state.toast===msg)self.setState({toast:''});},3200); }
    async load(){
      this.setState({loading:true,error:''});
      try{
        var user=null; try{var ud=await ZAF.get('currentUser'); user=ud.currentUser;}catch(ignore){}
        var results=await Promise.all([listCustomRecords(CLIENT_OBJECT),listCustomRecords(CONNECTION_OBJECT).catch(function(){return [];})]);
        var clients=results[0].sort(function(a,b){return safeString(a.name).localeCompare(safeString(b.name));}), conns={};
        results[1].forEach(function(r){var id=r.custom_object_fields&&r.custom_object_fields.cxe_client;if(id)conns[id]=r;});
        this.setState({clients:clients,connections:conns,selected:this.state.selected||(clients[0]&&clients[0].id),loading:false,currentUser:user});
        this.verifySchema();
      }catch(e){ this.setState({loading:false,error:e.message||String(e)}); }
    }
    async verifySchema(){
      var checks=[];
      try{await zafRequest('/api/v2/custom_objects/'+CLIENT_OBJECT,'GET');checks.push({label:'Existing client object',ok:true});}catch(e){checks.push({label:'Existing client object',ok:false,detail:'Missing'});}
      try{
        await zafRequest('/api/v2/custom_objects/'+CONNECTION_OBJECT,'GET'); checks.push({label:'CXE connection object',ok:true});
        var fd=await zafRequest('/api/v2/custom_objects/'+CONNECTION_OBJECT+'/fields','GET'); var found={}; arr(fd.custom_object_fields).forEach(function(x){found[x.key]=x;});
        REQUIRED_FIELDS.forEach(function(x){
          var actual=found[x.key], expected=expectedFieldType(x), received=expectedFieldType(actual), ok=!!actual && received===expected;
          checks.push({label:'Field '+x.key,ok:ok,detail:actual?'Expected '+expected+', found '+received:'Missing'});
        });
      }catch(e){ checks.push({label:'CXE connection object',ok:false,detail:'Missing'}); }
      try{
        await zafRequest('/api/v2/custom_objects/'+JOB_OBJECT,'GET');checks.push({label:'CXE temporary sync job object',ok:true});
        var jd=await zafRequest('/api/v2/custom_objects/'+JOB_OBJECT+'/fields','GET'), jobFound={};arr(jd.custom_object_fields).forEach(function(x){jobFound[x.key]=x;});
        REQUIRED_JOB_FIELDS.forEach(function(x){var actual=jobFound[x.key],ok=!!actual&&actual.type===x.type;checks.push({label:'Job field '+x.key,ok:ok,detail:actual?'Expected '+x.type+', found '+actual.type:'Missing'});});
      }catch(e){checks.push({label:'CXE temporary sync job object',ok:false,detail:'Missing'});}
      try{var hasZis=await zisIntegrationExists();checks.push({label:'Zendesk Integration Services',ok:hasZis,detail:hasZis?'':'Run Setup / Repair to register the app integration.'});}catch(e){checks.push({label:'Zendesk Integration Services',ok:false,detail:e.message||'Unavailable'});}
      this.setState({checks:checks}); return checks;
    }
    async runRepair(){
      this.setState({busy:true,setupResult:null});
      try{
        var isAdmin=this.state.currentUser && (this.state.currentUser.role==='admin' || this.state.currentUser.role==='account_owner');
        var exists=true; try{await zafRequest('/api/v2/custom_objects/'+CONNECTION_OBJECT,'GET');}catch(e){exists=false;}
        if(!exists){
          if(!isAdmin) throw new Error('The app-owned custom object is missing. An administrator must run Setup / Repair or reinstall the package so requirements.json can provision it.');
          await zafRequest('/api/v2/custom_objects','POST',{custom_object:{key:CONNECTION_OBJECT,title:'CXE Zendesk Config Connection',title_pluralized:'CXE Zendesk Config Connections',include_in_list_view:false}});
        }
        var fd=await zafRequest('/api/v2/custom_objects/'+CONNECTION_OBJECT+'/fields','GET'); var found={}; arr(fd.custom_object_fields).forEach(function(x){found[x.key]=x;});
        if(isAdmin){
          for(var i=0;i<REQUIRED_FIELDS.length;i++){
            var spec=REQUIRED_FIELDS[i]; if(found[spec.key]) continue;
            await zafRequest('/api/v2/custom_objects/'+CONNECTION_OBJECT+'/fields','POST',{custom_object_field:spec});
          }
        }
        var jobExists=true;try{await zafRequest('/api/v2/custom_objects/'+JOB_OBJECT,'GET');}catch(e){jobExists=false;}
        if(!jobExists){
          if(!isAdmin)throw new Error('The temporary sync job object is missing. An administrator must run Setup / Repair.');
          await zafRequest('/api/v2/custom_objects','POST',{custom_object:{key:JOB_OBJECT,title:'CXE Zendesk Config Sync Job',title_pluralized:'CXE Zendesk Config Sync Jobs',include_in_list_view:false}});
        }
        var jd=await zafRequest('/api/v2/custom_objects/'+JOB_OBJECT+'/fields','GET'),jobFound={};arr(jd.custom_object_fields).forEach(function(x){jobFound[x.key]=x;});
        if(isAdmin){for(var j=0;j<REQUIRED_JOB_FIELDS.length;j++){var jobSpec=REQUIRED_JOB_FIELDS[j];if(!jobFound[jobSpec.key])await zafRequest('/api/v2/custom_objects/'+JOB_OBJECT+'/fields','POST',{custom_object_field:jobSpec});}}
        await ensureZisIntegration();
        var connectionRecords=await listCustomRecords(CONNECTION_OBJECT).catch(function(){return [];});
        if(zisMappings(connectionRecords).length)await installZisBundle(connectionRecords);
        var checks=await this.verifySchema(); var bad=checks.filter(function(x){return !x.ok;});
        if(bad.length) throw new Error('Schema still has '+bad.length+' issue(s). '+(!isAdmin?'Ask an administrator to run repair.':'Review the failed fields.'));
        this.setState({setupResult:{ok:true,message:'Schema and Zendesk-hosted ZIS are healthy. Existing records were preserved and no external service is required.'}}); this.notify('Setup / Repair completed.'); await this.load();
      }catch(e){this.setState({setupResult:{ok:false,message:e.message||String(e)}});} finally{this.setState({busy:false});}
    }
    selectedClient(){return this.state.clients.find(function(c){return c.id===this.state.selected;}.bind(this));}
    selectedConnection(){return this.state.connections[this.state.selected];}
    selectClient(id){this.setState({selected:id,tab:'overview',sectionSearch:'',syncData:{},syncErrors:{},progress:''});}
    openConnect(){var conn=this.selectedConnection(), f=conn&&conn.custom_object_fields||{};this.setState({modal:'connect',connectionForm:{domain:f.cxe_domain||'',email:f.cxe_api_email||'',token:''}});}
    async submitConnection(){
      var clientRec=this.selectedClient(), form=this.state.connectionForm; if(!clientRec)return;
      this.setState({busy:true,error:''});
      var candidateName='', oldName='', connectionRecords=[];
      try{
        var domain=normalizeDomain(form.domain); if(!form.email)throw new Error('Enter the Zendesk API email.'); if(!form.token)throw new Error('Enter a Zendesk API token.');
        var existing=this.selectedConnection(), old=existing&&existing.custom_object_fields||{};
        oldName=safeString(old.cxe_zis_connection_name);
        try{await zafRequest('/api/v2/custom_objects/'+JOB_OBJECT,'GET');}catch(ignore){throw new Error('Run Setup / Repair once before connecting a client.');}
        await ensureZisIntegration();
        candidateName=await createZisConnection(clientRec.id,domain,form.email,form.token);
        connectionRecords=await listCustomRecords(CONNECTION_OBJECT).catch(function(){return [];});
        await installZisBundle(connectionRecords,{clientId:clientRec.id,connectionName:candidateName,domain:domain});
        this.setState({progress:'Zendesk ZIS is testing the API token…'});
        var tested=await fetchZisSpecs(clientRec.id,domain,[{key:'__test__',root:'user',url:ZIS_CORE.withPageSize(domain,'/api/v2/users/me.json'),optional:false}]);
        var testUser=tested.raw.__test__&&tested.raw.__test__.user;
        if(!testUser)throw new Error('Zendesk ZIS did not return the authenticated user.');
        var fields={cxe_client:clientRec.id,cxe_domain:domain,cxe_api_email:form.email.trim(),cxe_auth_type:'api_token',cxe_credential_envelope:'',cxe_zis_connection_name:candidateName,cxe_enabled:true,cxe_connection_status:'connected',cxe_last_test_at:nowIso(),cxe_last_sync_at:old.cxe_last_sync_at||'',cxe_last_http_status:200,cxe_last_error:'',cxe_credential_updated_at:nowIso(),cxe_auth_version:TOKEN_STORAGE_VERSION};
        await upsertConnection(clientRec,fields);
        if(oldName&&oldName!==candidateName)await deleteZisConnection(oldName);
        this.setState({modal:null,progress:'',connectionForm:{domain:'',email:'',token:''}}); await this.load(); this.notify('Connection tested and stored securely in Zendesk ZIS.');
      }catch(e){
        if(candidateName)try{await deleteZisConnection(candidateName);}catch(ignore){}
        if(connectionRecords.length)try{await installZisBundle(connectionRecords);}catch(ignore){}
        this.setState({progress:'',error:e.message||String(e)});
      } finally{this.setState({busy:false});}
    }
    async getZisConnection(){
      var conn=this.selectedConnection(); if(!conn)throw new Error('Connect this client first.'); var f=conn.custom_object_fields||{};
      if(f.cxe_enabled===false || f.cxe_enabled==='false')throw new Error('This connection is disabled.');
      if(!f.cxe_zis_connection_name)throw new Error('This connection uses an older credential format. Replace the credential once to move it into Zendesk ZIS.');
      return {clientId:this.state.selected,domain:normalizeDomain(f.cxe_domain),email:f.cxe_api_email,connectionName:f.cxe_zis_connection_name};
    }
    async updateConnectionFields(patch){
      var clientRec=this.selectedClient(), conn=this.selectedConnection(); if(!clientRec||!conn)return; var f=Object.assign({},conn.custom_object_fields||{},patch); await upsertConnection(clientRec,f); await this.load();
    }
    async toggleEnabled(){
      var conn=this.selectedConnection(); if(!conn)return; var f=conn.custom_object_fields||{}, enabled=!(f.cxe_enabled===false||f.cxe_enabled==='false');
      this.setState({busy:true}); try{await this.updateConnectionFields({cxe_enabled:!enabled,cxe_connection_status:!enabled?'connected':'disabled'});this.notify(!enabled?'Connection enabled.':'Connection disabled.');}catch(e){this.setState({error:e.message});}finally{this.setState({busy:false});}
    }
    async removeConnection(){
      var clientRec=this.selectedClient(); if(!clientRec)return; if(!confirm('Remove the saved connection for '+clientRec.name+'? The Client record is not deleted.'))return;
      var conn=this.selectedConnection(),name=conn&&conn.custom_object_fields&&conn.custom_object_fields.cxe_zis_connection_name;
      this.setState({busy:true}); try{await deleteConnection(clientRec);var remaining=await listCustomRecords(CONNECTION_OBJECT).catch(function(){return [];});if(zisMappings(remaining).length)await installZisBundle(remaining);await deleteZisConnection(name);this.setState({syncData:{}});await this.load();this.notify('Connection and its Zendesk ZIS credential were removed.');}catch(e){this.setState({error:e.message});}finally{this.setState({busy:false});}
    }
    async testConnection(){
      var conn=this.selectedConnection(); if(!conn)return; this.setState({busy:true,error:''});
      try{var connection=await this.getZisConnection();this.setState({progress:'Zendesk ZIS is testing the connection…'});var tested=await fetchZisSpecs(connection.clientId,connection.domain,[{key:'__test__',root:'user',url:ZIS_CORE.withPageSize(connection.domain,'/api/v2/users/me.json'),optional:false}]);if(!(tested.raw.__test__&&tested.raw.__test__.user))throw new Error('Zendesk ZIS did not return the authenticated user.');await this.updateConnectionFields({cxe_connection_status:'connected',cxe_last_test_at:nowIso(),cxe_last_http_status:200,cxe_last_error:''});this.notify('Connection test successful.');}
      catch(e){try{await this.updateConnectionFields(Object.assign({cxe_last_test_at:nowIso()},connectionFailure(e)));}catch(ignore){} this.setState({error:e.message});}
      finally{this.setState({busy:false,progress:''});}
    }
    async syncAll(){
      var conn=this.selectedConnection(), clientRec=this.selectedClient(); if(!conn||!clientRec)return; this.setState({busy:true,error:'',syncErrors:{},progress:'Preparing sync…'});
      try{
        var self=this,connection=await this.getZisConnection(), sectionKeys=SOURCE_DEFS.concat(GENERATED_DEFS).map(function(d){return d.key;}), result=await fetchConfiguration(connection.clientId,connection.domain,sectionKeys,function(message){self.setState({progress:message});}), data=result.data||{}, errors=result.errors||{};
        var errorKeys=Object.keys(errors), summary=errorKeys.length?errorKeys.length+' section(s) could not be read: '+errorKeys.join(', '):'';
        await this.updateConnectionFields({cxe_connection_status:'connected',cxe_last_sync_at:result.syncedAt||nowIso(),cxe_last_test_at:nowIso(),cxe_last_http_status:200,cxe_last_error:summary});
        this.setState({syncData:data,syncErrors:errors,progress:'',tab:'overview'}); this.notify('Configuration sync completed.');
      }catch(e){try{await this.updateConnectionFields(connectionFailure(e));}catch(ignore){}this.setState({progress:'',error:e.message||String(e)});} finally{this.setState({busy:false});}
    }
    async syncSection(key){
      var d=sectionDef(key); if(!d)return; var conn=this.selectedConnection(); this.setState({busy:true,error:'',progress:'Syncing '+d.label+'…'});
      try{
        var self=this,connection=await this.getZisConnection(), result=await fetchConfiguration(connection.clientId,connection.domain,[key],function(message){self.setState({progress:message});}), items=result.data&&result.data[key]||[], data=Object.assign({},this.state.syncData);
        data[key]=items;var errs=Object.assign({},this.state.syncErrors);delete errs[key];this.setState({syncData:data,syncErrors:errs,progress:''});
        await this.updateConnectionFields({cxe_connection_status:'connected',cxe_last_sync_at:nowIso(),cxe_last_http_status:200,cxe_last_error:''});this.notify(d.label+' refreshed.');
      }
      catch(e){try{await this.updateConnectionFields(connectionFailure(e));}catch(ignore){}var er=Object.assign({},this.state.syncErrors);er[key]=e.message;this.setState({syncErrors:er,progress:'',error:e.message});} finally{this.setState({busy:false});}
    }
    async copySection(kind){
      var clientRec=this.selectedClient(), key=this.state.tab, d=sectionDef(key); if(!d)return; var items=this.state.syncData[key]||[];
      var text=kind==='json'?JSON.stringify(sanitize(items),null,2):markdownForSection(clientRec.name,d.label,items); await copyText(text);this.notify(kind==='json'?'JSON copied.':'LLM-friendly Markdown copied.');
    }
    exportSection(kind){
      var clientRec=this.selectedClient(), key=this.state.tab, d=sectionDef(key); if(!d)return;var items=this.state.syncData[key]||[],base=clientRec.name.toLowerCase().replace(/[^a-z0-9]+/g,'-')+'-'+key;
      if(kind==='csv')downloadText(base+'.csv',sectionToCsv(items),'text/csv;charset=utf-8');else downloadText(base+'.json',JSON.stringify(sanitize(items),null,2),'application/json');
    }
    async copyWhole(){var c=this.selectedClient(); if(!c)return; var clean=sanitize(this.state.syncData);await copyText('# Zendesk Configuration\n\nClient: '+c.name+'\nCaptured: '+nowIso()+'\n\n```json\n'+JSON.stringify(clean,null,2)+'\n```');this.notify('Whole configuration copied for AI.');}
    exportWhole(){var c=this.selectedClient();if(!c)return;downloadText(c.name.toLowerCase().replace(/[^a-z0-9]+/g,'-')+'-zendesk-config.json',JSON.stringify(sanitize(this.state.syncData),null,2),'application/json');}
    render(){
      var self=this, s=this.state, clients=s.clients.filter(function(c){return safeString(c.name).toLowerCase().indexOf(s.filter.toLowerCase())>=0;}), selected=this.selectedClient(), conn=this.selectedConnection(), cf=conn&&conn.custom_object_fields||{}, si=statusInfo(conn);
      var configDefs=SOURCE_DEFS.concat(GENERATED_DEFS), allTabs=[{key:'overview',label:'Overview'}].concat(configDefs.map(function(d){return {key:d.key,label:d.label};}));
      allTabs.push({key:'setup',label:'Setup / Repair'});
      var currentDef=sectionDef(s.tab);
      return h('div',{className:'shell'},
        h('header',{className:'topbar'},h('div',{className:'brand'},h('div',{className:'brand-mark'},'CX'),h('div',null,h('div',{className:'brand-title'},'Zendesk Config Sync'),h('div',{className:'brand-sub'},'CX Experts · read-only configuration intelligence'))),h('div',{className:'top-actions'},h('span',{className:'badge muted'},s.currentUser?s.currentUser.name:'Zendesk session'),h('button',{className:'btn',onClick:function(){self.setState({tab:'setup'});}},'Setup / Repair'),h('button',{className:'btn',onClick:function(){self.load();}},'Reload clients'))),
        h('div',{className:'content'},
          h(ClientList,{clients:clients,connections:s.connections,selected:s.selected,filter:s.filter,onFilter:function(v){self.setState({filter:v});},onSelect:this.selectClient}),
          h('main',{className:'main'},
            s.loading?h('div',{className:'empty'},h('span',{className:'spinner'}),'Loading Zendesk clients…'):
            s.error&&!selected?h('div',{className:'notice error'},s.error):
            !selected?h('div',{className:'empty'},h('h3',null,'No client selected'),h('div',null,'Select a Client record from the left.')):
            h('div',null,
              h('div',{className:'page-head'},h('div',null,h('h1',{className:'page-title'},selected.name),h('div',{className:'page-meta'},h('span',{className:'status-dot '+si.color}), ' '+si.label+(cf.cxe_domain?' · '+cf.cxe_domain:'')+(cf.cxe_last_sync_at?' · Last sync '+humanTime(cf.cxe_last_sync_at):''))),
                h('div',{className:'button-row'},
                  !conn?h('button',{className:'btn primary',onClick:function(){self.openConnect();}},'Connect Zendesk'):null,
                  conn?h('button',{className:'btn primary',onClick:this.syncAll,disabled:s.busy||cf.cxe_enabled===false||cf.cxe_enabled==='false'},s.busy?h('span',null,h('span',{className:'spinner'}),'Working…'):'Sync all'):null,
                  conn?h('button',{className:'btn',onClick:function(){self.testConnection();},disabled:s.busy},'Test'):null,
                  conn?h('button',{className:'btn',onClick:function(){self.openConnect();},disabled:s.busy},'Replace credential'):null,
                  conn?h('button',{className:'btn',onClick:function(){self.toggleEnabled();},disabled:s.busy},(cf.cxe_enabled===false||cf.cxe_enabled==='false')?'Enable':'Disable'):null,
                  conn?h('button',{className:'btn danger',onClick:function(){self.removeConnection();},disabled:s.busy},'Remove'):null)),
              s.error?h('div',{className:'notice error'},s.error,h('button',{className:'close',style:{float:'right'},onClick:function(){self.setState({error:''});}},'×')):null,
              conn?h('div',{className:'tabs'},allTabs.map(function(t){return h('button',{key:t.key,className:'tab'+(s.tab===t.key?' active':''),onClick:function(){self.setState({tab:t.key,sectionSearch:''});}},t.label);})):null,
              s.tab==='setup'?h(SetupView,{checks:s.checks,lastResult:s.setupResult,busy:s.busy,onRepair:this.runRepair}):
              !conn?h('div',{className:'panel'},h('div',{className:'panel-body empty'},h('h3',null,'Not connected'),h('div',null,'This Client record exists in CX Zendesk but has no Config Sync connection yet.'),h('div',{className:'footer-note'},'Connect it with a Zendesk API email and token. Zendesk ZIS performs the configuration reads; no ticket data is retrieved.'))):
              s.tab==='overview'?h('div',null,h('div',{className:'button-row',style:{marginBottom:'12px'}},h('button',{className:'btn',onClick:function(){self.copyWhole();},disabled:!Object.keys(s.syncData).length},'Copy whole config for AI'),h('button',{className:'btn',onClick:function(){self.exportWhole();},disabled:!Object.keys(s.syncData).length},'Export whole JSON')),h(Overview,{data:s.syncData,defs:configDefs,progress:s.progress})):
              currentDef?h(SectionView,{label:currentDef.label,items:s.syncData[s.tab]||[],error:s.syncErrors[s.tab],search:s.sectionSearch,onSearch:function(v){self.setState({sectionSearch:v});},busy:s.busy,onRefresh:function(){self.syncSection(s.tab);},onCopy:function(k){self.copySection(k);},onExport:function(k){self.exportSection(k);}}):null
            ))),
        s.modal==='connect'?h(ConnectionModal,{connection:conn,form:s.connectionForm,busy:s.busy,onClose:function(){self.setState({modal:null,error:''});},set:function(k,v){var f=Object.assign({},s.connectionForm);f[k]=v;self.setState({connectionForm:f});},onSubmit:function(){self.submitConnection();}}):null,
        s.toast?h('div',{className:'toast'},s.toast):null);
    }
  }

  if(!window.React || !window.ReactDOM || !window.CXEZIS){ document.getElementById('root').innerHTML='<div style="padding:24px;font-family:sans-serif">The app runtime could not be loaded.</div>'; return; }
  ReactDOM.createRoot(document.getElementById('root')).render(h(App));
})();
